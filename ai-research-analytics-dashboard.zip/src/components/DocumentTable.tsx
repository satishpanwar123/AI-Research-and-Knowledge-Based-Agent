import { useEffect, useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  ChevronLeft,
  ChevronRight,
  Download,
  Search,
} from "lucide-react";
import {
  DOC_TYPES,
  STATUSES,
  longDate,
  nf,
  type Doc,
  type Status,
} from "../lib/data";

type SortKey =
  | "title"
  | "type"
  | "audience"
  | "source"
  | "ts"
  | "pages"
  | "questions"
  | "minutesSaved"
  | "confidence"
  | "status";

const COLUMNS: { key: SortKey; label: string; align?: "right" | "left"; hide?: string }[] = [
  { key: "title", label: "Document" },
  { key: "type", label: "Type", hide: "hidden lg:table-cell" },
  { key: "audience", label: "Audience", hide: "hidden xl:table-cell" },
  { key: "source", label: "Source", hide: "hidden md:table-cell" },
  { key: "ts", label: "Added", hide: "hidden md:table-cell" },
  { key: "pages", label: "Pages", align: "right", hide: "hidden xl:table-cell" },
  { key: "questions", label: "Questions", align: "right" },
  { key: "minutesSaved", label: "Time saved", align: "right" },
  { key: "confidence", label: "Confidence", align: "right", hide: "hidden sm:table-cell" },
  { key: "status", label: "Status", hide: "hidden sm:table-cell" },
];

const STATUS_STYLE: Record<Status, string> = {
  Indexed: "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400",
  Processing: "bg-sky-500/12 text-sky-600 dark:text-sky-400",
  "Needs Review": "bg-amber-500/14 text-amber-600 dark:text-amber-400",
  Archived: "bg-slate-500/12 text-slate-500 dark:text-slate-400",
};

const TYPE_COLOR: Record<string, string> = {
  "Research Paper": "#6366f1",
  "PDF Report": "#06b6d4",
  "Technical Doc": "#f59e0b",
  "Article / Blog": "#ec4899",
  "Lecture Slides": "#10b981",
};

export default function DocumentTable({
  docs,
  search,
  onSearch,
  onOpen,
}: {
  docs: Doc[];
  search: string;
  onSearch: (v: string) => void;
  onOpen: (d: Doc) => void;
}) {
  const [sort, setSort] = useState<SortKey>("ts");
  const [dir, setDir] = useState<"asc" | "desc">("desc");
  const [status, setStatus] = useState<string>("All");
  const [type, setType] = useState<string>("All");
  const [page, setPage] = useState(1);
  const perPage = 8;

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return docs.filter((d) => {
      if (status !== "All" && d.status !== status) return false;
      if (type !== "All" && d.type !== type) return false;
      if (q) {
        const hay = `${d.title} ${d.topic} ${d.source} ${d.type} ${d.audience} ${d.id}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [docs, search, status, type]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    arr.sort((a, b) => {
      const av = a[sort];
      const bv = b[sort];
      const cmp =
        typeof av === "string" && typeof bv === "string"
          ? av.localeCompare(bv)
          : (av as number) - (bv as number);
      return dir === "asc" ? cmp : -cmp;
    });
    return arr;
  }, [filtered, sort, dir]);

  const pages = Math.max(1, Math.ceil(sorted.length / perPage));
  useEffect(() => {
    if (page > pages) setPage(1);
  }, [pages, page]);

  const rows = sorted.slice((page - 1) * perPage, page * perPage);

  const toggleSort = (k: SortKey) => {
    if (sort === k) setDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSort(k);
      setDir(k === "title" || k === "type" || k === "audience" || k === "source" ? "asc" : "desc");
    }
  };

  const exportCsv = () => {
    const head = [
      "ID",
      "Title",
      "Topic",
      "Type",
      "Audience",
      "Source",
      "Added",
      "Pages",
      "Questions",
      "MinutesSaved",
      "Confidence",
      "Status",
    ];
    const lines = sorted.map((d) =>
      [
        d.id,
        `"${d.title.replace(/"/g, "'")}"`,
        d.topic,
        d.type,
        d.audience,
        d.source,
        d.date,
        d.pages,
        d.questions,
        d.minutesSaved,
        d.confidence.toFixed(3),
        d.status,
      ].join(",")
    );
    const blob = new Blob([[head.join(","), ...lines].join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "cortex-documents.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section className="animate-fade-up rounded-2xl border border-slate-200 bg-white p-4 shadow-sm shadow-slate-900/[0.03] sm:p-5 dark:border-slate-800 dark:bg-slate-900/60 dark:shadow-black/20">
      <header className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-[15px] font-semibold tracking-tight text-slate-900 dark:text-white">
            Document activity
          </h3>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            {nf.format(sorted.length)} documents match the current filters · click a row to open the
            summary, findings and citations
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <label className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={(e) => {
                onSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search…"
              className="h-9 w-40 rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-2 text-[12px] outline-none transition-all focus:border-indigo-400 focus:bg-white focus:ring-2 focus:ring-indigo-500/15 sm:w-52 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
            />
          </label>
          <select
            value={type}
            onChange={(e) => {
              setType(e.target.value);
              setPage(1);
            }}
            className="h-9 rounded-lg border border-slate-200 bg-white px-2 text-[12px] text-slate-600 outline-none focus:border-indigo-400 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
          >
            <option value="All">All types</option>
            {DOC_TYPES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
          <select
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setPage(1);
            }}
            className="h-9 rounded-lg border border-slate-200 bg-white px-2 text-[12px] text-slate-600 outline-none focus:border-indigo-400 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
          >
            <option value="All">All statuses</option>
            {STATUSES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
          <button
            onClick={exportCsv}
            className="flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 px-2.5 text-[12px] font-semibold text-slate-600 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
          >
            <Download className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>
      </header>

      <div className="-mx-4 overflow-x-auto sm:-mx-5">
        <table className="w-full min-w-[720px] border-collapse text-left">
          <thead>
            <tr className="border-y border-slate-200 bg-slate-50/60 dark:border-slate-800 dark:bg-slate-800/40">
              {COLUMNS.map((c) => {
                const on = sort === c.key;
                return (
                  <th
                    key={c.key}
                    className={`px-3 py-2.5 text-[11px] font-semibold uppercase tracking-wider ${
                      c.hide || ""
                    } ${c.align === "right" ? "text-right" : "text-left"}`}
                  >
                    <button
                      onClick={() => toggleSort(c.key)}
                      className={`inline-flex items-center gap-1 transition-colors ${
                        on
                          ? "text-indigo-600 dark:text-indigo-400"
                          : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                      }`}
                    >
                      {c.label}
                      {on &&
                        (dir === "asc" ? (
                          <ArrowUp className="h-3 w-3" strokeWidth={3} />
                        ) : (
                          <ArrowDown className="h-3 w-3" strokeWidth={3} />
                        ))}
                    </button>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {rows.map((d) => (
              <tr
                key={d.id + d.ts}
                onClick={() => onOpen(d)}
                className="group cursor-pointer border-b border-slate-100 transition-colors last:border-0 hover:bg-slate-50/80 dark:border-slate-800/70 dark:hover:bg-slate-800/40"
                title="Click to open this document"
              >
                <td className="max-w-[320px] px-3 py-3">
                  <div className="flex items-start gap-2.5">
                    <span
                      className="mt-1 h-2 w-2 shrink-0 rounded-full"
                      style={{ background: TYPE_COLOR[d.type] }}
                    />
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-medium text-slate-800 decoration-indigo-400 decoration-1 underline-offset-2 group-hover:text-indigo-600 group-hover:underline dark:text-slate-100 dark:group-hover:text-indigo-300">
                        {d.title}
                      </p>
                      <p className="mt-0.5 truncate text-[11px] text-slate-400">
                        {d.topic} · {d.id}
                      </p>
                    </div>
                  </div>
                </td>
                <td className="hidden px-3 py-3 lg:table-cell">
                  <span className="whitespace-nowrap text-[12px] text-slate-500 dark:text-slate-400">
                    {d.type}
                  </span>
                </td>
                <td className="hidden px-3 py-3 xl:table-cell">
                  <span className="whitespace-nowrap text-[12px] text-slate-500 dark:text-slate-400">
                    {d.audience}
                  </span>
                </td>
                <td className="hidden px-3 py-3 md:table-cell">
                  <span className="whitespace-nowrap text-[12px] text-slate-500 dark:text-slate-400">
                    {d.source}
                  </span>
                </td>
                <td className="hidden whitespace-nowrap px-3 py-3 md:table-cell">
                  <span className="text-[12px] text-slate-500 dark:text-slate-400">
                    {longDate(d.date)}
                  </span>
                </td>
                <td className="hidden px-3 py-3 text-right xl:table-cell">
                  <span className="text-[12px] tabular-nums text-slate-500 dark:text-slate-400">
                    {d.pages}
                  </span>
                </td>
                <td className="px-3 py-3 text-right">
                  <span className="text-[13px] font-semibold tabular-nums text-slate-700 dark:text-slate-200">
                    {nf.format(d.questions)}
                  </span>
                </td>
                <td className="px-3 py-3 text-right">
                  <span className="text-[12px] tabular-nums text-slate-500 dark:text-slate-400">
                    {d.minutesSaved >= 60
                      ? `${(d.minutesSaved / 60).toFixed(1)}h`
                      : `${d.minutesSaved}m`}
                  </span>
                </td>
                <td className="hidden px-3 py-3 sm:table-cell">
                  <div className="flex items-center justify-end gap-2">
                    <div className="hidden h-1.5 w-16 overflow-hidden rounded-full bg-slate-100 sm:block dark:bg-slate-700">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${d.confidence * 100}%`,
                          background:
                            d.confidence > 0.92
                              ? "#10b981"
                              : d.confidence > 0.86
                              ? "#6366f1"
                              : "#f59e0b",
                        }}
                      />
                    </div>
                    <span className="w-10 text-right text-[12px] font-semibold tabular-nums text-slate-700 dark:text-slate-200">
                      {(d.confidence * 100).toFixed(0)}%
                    </span>
                  </div>
                </td>
                <td className="hidden px-3 py-3 sm:table-cell">
                  <span
                    className={`whitespace-nowrap rounded-md px-2 py-1 text-[11px] font-semibold ${STATUS_STYLE[d.status]}`}
                  >
                    {d.status}
                  </span>
                </td>
              </tr>
            ))}
            {!rows.length && (
              <tr>
                <td colSpan={COLUMNS.length} className="px-3 py-14 text-center">
                  <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
                    No documents match these filters
                  </p>
                  <p className="mt-1 text-xs text-slate-400">
                    Try widening the date range or re-enabling a segment.
                  </p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <footer className="mt-3 flex flex-wrap items-center justify-between gap-3">
        <p className="text-[11px] text-slate-400">
          Showing{" "}
          <span className="font-semibold text-slate-600 dark:text-slate-300">
            {sorted.length ? (page - 1) * perPage + 1 : 0}–
            {Math.min(page * perPage, sorted.length)}
          </span>{" "}
          of <span className="font-semibold text-slate-600 dark:text-slate-300">{nf.format(sorted.length)}</span>
        </p>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-500 transition-colors hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:hover:bg-slate-800"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          {Array.from({ length: Math.min(5, pages) }).map((_, i) => {
            const start = Math.min(Math.max(1, page - 2), Math.max(1, pages - 4));
            const n = start + i;
            return (
              <button
                key={n}
                onClick={() => setPage(n)}
                className={`h-8 w-8 rounded-lg text-[12px] font-semibold transition-colors ${
                  n === page
                    ? "bg-slate-900 text-white dark:bg-indigo-500"
                    : "border border-slate-200 text-slate-500 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
                }`}
              >
                {n}
              </button>
            );
          })}
          <button
            onClick={() => setPage((p) => Math.min(pages, p + 1))}
            disabled={page === pages}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-500 transition-colors hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:hover:bg-slate-800"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </footer>
      <p className="mt-2 text-[10px] text-slate-400">
        Segment selection (audience, document type, source) is synced live with the toolbar
        filters above. Click any column header to sort.
      </p>
    </section>
  );
}
