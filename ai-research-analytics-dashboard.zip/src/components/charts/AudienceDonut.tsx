import { useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import ChartTooltip from "./ChartTooltip";
import { compact, type Bucket } from "../../lib/data";

const COLORS = ["#6366f1", "#06b6d4", "#f59e0b", "#ec4899", "#10b981", "#8b5cf6"];

export default function AudienceDonut({
  data,
  dark,
  title,
}: {
  data: Bucket[];
  dark: boolean;
  title: string;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const total = data.reduce((a, b) => a + b.value, 0) || 1;
  const active = hover != null ? data[hover] : null;

  return (
    <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
      <div className="relative mx-auto h-[212px] w-[212px] shrink-0">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Tooltip
              content={({ active: a, payload }: any) => {
                if (!a || !payload?.length) return null;
                const row = payload[0].payload as Bucket;
                const idx = Math.max(
                  0,
                  data.findIndex((x) => x.key === row.key)
                );
                return (
                  <ChartTooltip
                    dark={dark}
                    title={`${compact(row.value)} questions`}
                    rows={[
                      {
                        label: row.label,
                        value: `${((row.value / total) * 100).toFixed(1)}%`,
                        color: row.color || COLORS[idx % COLORS.length],
                      },
                    ]}
                    footer={`${compact(row.secondary)} documents ingested by this segment`}
                  />
                );
              }}
            />
            <Pie
              data={data as any}
              dataKey="value"
              nameKey="label"
              innerRadius={64}
              outerRadius={94}
              paddingAngle={2.5}
              startAngle={90}
              endAngle={-270}
              stroke={dark ? "#0b1220" : "#ffffff"}
              strokeWidth={2}
              animationDuration={800}
              onMouseEnter={(_: any, i: number) => setHover(i)}
              onMouseLeave={() => setHover(null)}
            >
              {data.map((d, i) => (
                <Cell
                  key={d.key}
                  fill={d.color || COLORS[i % COLORS.length]}
                  fillOpacity={hover == null || hover === i ? 1 : 0.28}
                  style={{ transition: "fill-opacity 220ms ease", cursor: "pointer" }}
                />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-[10px] font-semibold uppercase tracking-widest text-slate-400">
            {active ? active.label : "Total"}
          </span>
          <span className="text-2xl font-bold tabular-nums text-slate-900 dark:text-white">
            {compact(active ? active.value : total)}
          </span>
          <span className="text-[11px] text-slate-400">
            {active ? `${((active.value / total) * 100).toFixed(1)}% share` : title}
          </span>
        </div>
      </div>

      <ul className="flex-1 space-y-1.5">
        {data.map((d, i) => {
          const c = d.color || COLORS[i % COLORS.length];
          const share = (d.value / total) * 100;
          return (
            <li
              key={d.key}
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
              className={`flex cursor-default items-center gap-2.5 rounded-lg px-2 py-1.5 transition-colors ${
                hover === i ? "bg-slate-100 dark:bg-slate-800/70" : ""
              }`}
            >
              <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: c }} />
              <span className="min-w-0 flex-1 truncate text-[13px] text-slate-600 dark:text-slate-300">
                {d.label}
              </span>
              <span className="text-[13px] font-semibold tabular-nums text-slate-900 dark:text-white">
                {compact(d.value)}
              </span>
              <span className="w-11 text-right text-[11px] tabular-nums text-slate-400">
                {share.toFixed(1)}%
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
