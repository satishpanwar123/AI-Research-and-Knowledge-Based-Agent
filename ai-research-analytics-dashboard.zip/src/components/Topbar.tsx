import { Menu, Moon, RefreshCw, Search, Sun, Bell } from "lucide-react";

export default function Topbar({
  dark,
  onToggleTheme,
  onMenu,
  query,
  onQuery,
  lastSync,
  onRefresh,
  refreshing,
  page,
}: {
  dark: boolean;
  onToggleTheme: () => void;
  onMenu: () => void;
  query: string;
  onQuery: (v: string) => void;
  lastSync: string;
  onRefresh: () => void;
  refreshing: boolean;
  page: string;
}) {
  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-slate-200 bg-white/85 px-4 backdrop-blur-md sm:px-6 dark:border-slate-800 dark:bg-slate-950/85">
      <button
        onClick={onMenu}
        className="rounded-lg p-2 text-slate-500 transition-colors hover:bg-slate-100 lg:hidden dark:hover:bg-slate-800"
        aria-label="Open navigation"
      >
        <Menu className="h-5 w-5" />
      </button>

      <div className="min-w-0">
        <h1 className="truncate text-[15px] font-semibold tracking-tight text-slate-900 dark:text-white">
          {page}
        </h1>
        <p className="hidden text-[11px] text-slate-400 sm:block">
          AI research & knowledge intelligence
        </p>
      </div>

      <div className="ml-auto flex items-center gap-2">
        <label className="relative hidden md:block">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
          <input
            value={query}
            onChange={(e) => onQuery(e.target.value)}
            placeholder="Search documents, topics, sources…"
            className="h-9 w-56 rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-3 text-[13px] text-slate-700 outline-none transition-all placeholder:text-slate-400 focus:border-indigo-400 focus:bg-white focus:ring-2 focus:ring-indigo-500/15 lg:w-72 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:focus:border-indigo-500 dark:focus:bg-slate-900"
          />
        </label>

        <div className="hidden items-center gap-1.5 rounded-lg border border-slate-200 px-2.5 py-1.5 lg:flex dark:border-slate-700">
          <span className="live-dot h-1.5 w-1.5 rounded-full bg-emerald-500" />
          <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
            Synced {lastSync}
          </span>
        </div>

        <button
          onClick={onRefresh}
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-700 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
          aria-label="Refresh data"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
        </button>

        <button
          onClick={onToggleTheme}
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-700 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
          aria-label="Toggle dark mode"
        >
          {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>

        <button className="relative flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-500 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800">
          <Bell className="h-4 w-4" />
          <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-rose-500 ring-2 ring-white dark:ring-slate-950" />
        </button>

        <div className="ml-1 flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-[12px] font-bold text-white shadow-sm">
          AR
        </div>
      </div>
    </header>
  );
}
