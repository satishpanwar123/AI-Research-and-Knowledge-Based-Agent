import { TrendingDown, TrendingUp } from "lucide-react";
import Sparkline from "./Sparkline";
import type { LucideIcon } from "lucide-react";

type Props = {
  label: string;
  value: string;
  unit?: string;
  delta: number;
  deltaLabel?: string;
  spark: number[];
  color: string;
  icon: LucideIcon;
  hint: string;
  delay?: number;
  onClick?: () => void;
  active?: boolean;
};

export default function KpiCard({
  label,
  value,
  unit,
  delta,
  deltaLabel = "vs previous period",
  spark,
  color,
  icon: Icon,
  hint,
  delay = 0,
  onClick,
  active,
}: Props) {
  const up = delta >= 0;
  const Trend = up ? TrendingUp : TrendingDown;

  return (
    <button
      onClick={onClick}
      className={`group animate-fade-up relative overflow-hidden rounded-2xl border bg-white p-4 text-left shadow-sm shadow-slate-900/[0.03] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md dark:bg-slate-900/60 dark:shadow-black/20 ${
        active
          ? "border-indigo-400 ring-2 ring-indigo-500/20 dark:border-indigo-500"
          : "border-slate-200 hover:border-slate-300 dark:border-slate-800 dark:hover:border-slate-700"
      }`}
      style={{ animationDelay: `${delay}ms` }}
    >
      <div
        className="pointer-events-none absolute -right-8 -top-10 h-28 w-28 rounded-full opacity-[0.10] blur-2xl transition-opacity duration-300 group-hover:opacity-20"
        style={{ background: color }}
      />
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <span
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ background: `${color}18`, color }}
          >
            <Icon className="h-3.5 w-3.5" strokeWidth={2.4} />
          </span>
          <span className="text-[12px] font-medium text-slate-500 dark:text-slate-400">
            {label}
          </span>
        </div>
        <span
          className="flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-[11px] font-bold tabular-nums"
          style={{
            background: up ? "rgba(16,185,129,0.12)" : "rgba(244,63,94,0.12)",
            color: up ? "#059669" : "#e11d48",
          }}
          title={deltaLabel}
        >
          <Trend className="h-3 w-3" strokeWidth={3} />
          {Math.abs(delta * 100).toFixed(1)}%
        </span>
      </div>

      <div className="mt-3 flex items-baseline gap-1">
        <span className="text-[26px] font-bold leading-none tracking-tight tabular-nums text-slate-900 dark:text-white">
          {value}
        </span>
        {unit && (
          <span className="text-[13px] font-medium text-slate-400">{unit}</span>
        )}
      </div>

      <p className="mt-1 text-[11px] text-slate-400">{hint}</p>

      <div className="mt-2 -mx-1">
        <Sparkline values={spark} color={color} height={38} />
      </div>
    </button>
  );
}
