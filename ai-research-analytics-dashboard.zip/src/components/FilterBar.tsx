import { CalendarDays, RotateCcw, SlidersHorizontal, Users, FileText, Database } from "lucide-react";
import MultiSelect from "./MultiSelect";
import { AUDIENCES, DOC_TYPES, SOURCES, isoOf, DATA_START, DATA_END } from "../lib/data";

export type RangeKey = "7d" | "30d" | "90d" | "365d" | "custom";

const PRESETS: { key: RangeKey; label: string }[] = [
  { key: "7d", label: "7D" },
  { key: "30d", label: "30D" },
  { key: "90d", label: "90D" },
  { key: "365d", label: "12M" },
];

type Props = {
  range: RangeKey;
  onRange: (r: RangeKey) => void;
  start: string;
  end: string;
  onStart: (v: string) => void;
  onEnd: (v: string) => void;
  audiences: string[];
  onAudiences: (v: string[]) => void;
  docTypes: string[];
  onDocTypes: (v: string[]) => void;
  sources: string[];
  onSources: (v: string[]) => void;
  onReset: () => void;
  periodLabel: string;
  compareLabel: string;
  dirty: boolean;
};

export default function FilterBar(p: Props) {
  const minIso = isoOf(DATA_START);
  const maxIso = isoOf(DATA_END);

  return (
    <div className="sticky top-16 z-10 -mx-4 mb-5 border-b border-slate-200 bg-slate-50/90 px-4 py-3 backdrop-blur-md sm:-mx-6 sm:px-6 dark:border-slate-800 dark:bg-slate-950/80">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white p-0.5 dark:border-slate-700 dark:bg-slate-900">
          <span className="hidden pl-2 pr-1 text-slate-400 sm:block">
            <CalendarDays className="h-3.5 w-3.5" />
          </span>
          {PRESETS.map((r) => (
            <button
              key={r.key}
              onClick={() => p.onRange(r.key)}
              className={`rounded-md px-2.5 py-1 text-[12px] font-semibold transition-colors ${
                p.range === r.key
                  ? "bg-slate-900 text-white shadow-sm dark:bg-indigo-500"
                  : "text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              }`}
            >
              {r.label}
            </button>
          ))}
          <button
            onClick={() => p.onRange("custom")}
            className={`rounded-md px-2.5 py-1 text-[12px] font-semibold transition-colors ${
              p.range === "custom"
                ? "bg-slate-900 text-white shadow-sm dark:bg-indigo-500"
                : "text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
            }`}
          >
            Custom
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <input
            type="date"
            value={p.start}
            min={minIso}
            max={p.end}
            onChange={(e) => {
              p.onRange("custom");
              p.onStart(e.target.value);
            }}
            className="h-9 rounded-lg border border-slate-200 bg-white px-2 text-[12px] text-slate-600 outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/15 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
          />
          <span className="text-xs text-slate-400">→</span>
          <input
            type="date"
            value={p.end}
            min={p.start}
            max={maxIso}
            onChange={(e) => {
              p.onRange("custom");
              p.onEnd(e.target.value);
            }}
            className="h-9 rounded-lg border border-slate-200 bg-white px-2 text-[12px] text-slate-600 outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/15 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
          />
        </div>

        <div className="ml-auto flex flex-wrap items-center gap-2">
          <MultiSelect
            label="Audience"
            icon={<Users className="h-3.5 w-3.5" />}
            options={AUDIENCES}
            selected={p.audiences}
            onChange={p.onAudiences}
            accent="#6366f1"
          />
          <MultiSelect
            label="Doc type"
            icon={<FileText className="h-3.5 w-3.5" />}
            options={DOC_TYPES}
            selected={p.docTypes}
            onChange={p.onDocTypes}
            accent="#06b6d4"
          />
          <MultiSelect
            label="Source"
            icon={<Database className="h-3.5 w-3.5" />}
            options={SOURCES}
            selected={p.sources}
            onChange={p.onSources}
            accent="#f59e0b"
          />
          {p.dirty && (
            <button
              onClick={p.onReset}
              className="flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 px-3 text-[12px] font-semibold text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-800 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset
            </button>
          )}
        </div>
      </div>

      <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-400">
        <span className="flex items-center gap-1">
          <SlidersHorizontal className="h-3 w-3" />
          {p.periodLabel}
        </span>
        <span className="hidden sm:inline">·</span>
        <span>compared with {p.compareLabel}</span>
        <span className="hidden sm:inline">·</span>
        <span>{p.docTypes.length}/5 types · {p.audiences.length}/5 audiences · {p.sources.length}/5 sources</span>
      </div>
    </div>
  );
}
