import {
  BookOpen,
  LayoutDashboard,
  Layers,
  MessagesSquare,
  Network,
  Settings,
  Sparkles,
  X,
  GraduationCap,
  Database,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export const NAV: { label: string; icon: LucideIcon; badge?: string; section?: string }[] = [
  { label: "Overview", icon: LayoutDashboard, section: "Workspace" },
  { label: "Document Library", icon: BookOpen, section: "Workspace" },
  { label: "Ask & Answers", icon: MessagesSquare, badge: "New", section: "Workspace" },
  { label: "Topics & Graph", icon: Network, section: "Insights" },
  { label: "Collections", icon: Layers, section: "Insights" },
  { label: "Sources", icon: Database, section: "Insights" },
  { label: "Study Paths", icon: GraduationCap, section: "Programs" },
  { label: "Settings", icon: Settings, section: "Programs" },
];

export default function Sidebar({
  active,
  onSelect,
  open,
  onClose,
}: {
  active: string;
  onSelect: (s: string) => void;
  open: boolean;
  onClose: () => void;
}) {
  const groups = Array.from(new Set(NAV.map((n) => n.section!)));

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-30 bg-slate-900/40 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 shrink-0 flex-col border-r border-slate-200 bg-white transition-transform duration-300 dark:border-slate-800 dark:bg-slate-950 lg:static lg:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex h-16 items-center gap-2.5 border-b border-slate-200 px-5 dark:border-slate-800">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-cyan-400 shadow-lg shadow-indigo-500/30">
            <Sparkles className="h-4 w-4 text-white" strokeWidth={2.6} />
          </span>
          <div className="leading-tight">
            <p className="text-[15px] font-bold tracking-tight text-slate-900 dark:text-white">
              Cortex
            </p>
            <p className="text-[10px] font-medium uppercase tracking-widest text-slate-400">
              Research Intelligence
            </p>
          </div>
          <button
            onClick={onClose}
            className="ml-auto rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 lg:hidden dark:hover:bg-slate-800"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <nav className="flex-1 space-y-5 overflow-y-auto px-3 py-5">
          {groups.map((g) => (
            <div key={g}>
              <p className="mb-1.5 px-2 text-[10px] font-semibold uppercase tracking-widest text-slate-400">
                {g}
              </p>
              <ul className="space-y-0.5">
                {NAV.filter((n) => n.section === g).map((n) => {
                  const on = active === n.label;
                  return (
                    <li key={n.label}>
                      <button
                        onClick={() => {
                          onSelect(n.label);
                          onClose();
                        }}
                        className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] font-medium transition-colors ${
                          on
                            ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-300"
                            : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800/70 dark:hover:text-slate-200"
                        }`}
                      >
                        <n.icon className="h-4 w-4" strokeWidth={2.1} />
                        <span className="truncate">{n.label}</span>
                        {n.badge && (
                          <span className="ml-auto rounded bg-cyan-500/15 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-cyan-500">
                            {n.badge}
                          </span>
                        )}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>

        <div className="m-3 rounded-xl border border-slate-200 bg-gradient-to-br from-slate-50 to-indigo-50/60 p-3.5 dark:border-slate-800 dark:from-slate-900 dark:to-indigo-950/40">
          <p className="text-[12px] font-semibold text-slate-800 dark:text-slate-100">
            Deep Research agent
          </p>
          <p className="mt-1 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
            Queue 40 papers and get a cited synthesis in ~6 minutes.
          </p>
          <button className="mt-2.5 w-full rounded-lg bg-slate-900 px-3 py-1.5 text-[11px] font-semibold text-white transition-colors hover:bg-slate-700 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200">
            Start a research run
          </button>
        </div>
      </aside>
    </>
  );
}
