import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowUpRight,
  BookMarked,
  Check,
  Clock,
  Copy,
  Download,
  FileText,
  ListTree,
  Loader2,
  MessagesSquare,
  Quote,
  Send,
  Sparkles,
  Tag,
  X,
} from "lucide-react";
import Sparkline from "./Sparkline";
import { DOCUMENTS, longDate, nf, type Doc } from "../lib/data";
import { detailFor, freeformAnswer } from "../lib/detail";

const TYPE_COLOR: Record<string, string> = {
  "Research Paper": "#6366f1",
  "PDF Report": "#06b6d4",
  "Technical Doc": "#f59e0b",
  "Article / Blog": "#ec4899",
  "Lecture Slides": "#10b981",
};

const STATUS_STYLE: Record<string, string> = {
  Indexed: "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400",
  Processing: "bg-sky-500/12 text-sky-600 dark:text-sky-400",
  "Needs Review": "bg-amber-500/14 text-amber-600 dark:text-amber-400",
  Archived: "bg-slate-500/12 text-slate-500 dark:text-slate-400",
};

type Msg = { q: string; a: string; loading: boolean };

export default function DocumentDrawer({
  doc,
  onClose,
  onOpenOther,
  onAsk,
}: {
  doc: Doc | null;
  onClose: () => void;
  onOpenOther: (d: Doc) => void;
  onAsk: (d: Doc) => void;
}) {
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  const [thread, setThread] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [showOutline, setShowOutline] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const detail = useMemo(() => (doc ? detailFor(doc) : null), [doc]);

  useEffect(() => {
    setThread([]);
    setInput("");
    setCopied(false);
    setSaved(false);
    setShowOutline(false);
    scrollRef.current?.scrollTo({ top: 0 });
  }, [doc?.id]);

  useEffect(() => {
    if (!doc) return;
    const onEsc = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onEsc);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onEsc);
      document.body.style.overflow = "";
    };
  }, [doc, onClose]);

  if (!doc || !detail) return null;

  const related = DOCUMENTS.filter((d) => d.topic === doc.topic && d.id !== doc.id).slice(0, 4);
  const color = TYPE_COLOR[doc.type] ?? "#6366f1";

  const citation = `${detail.authors.join(", ")} (${detail.year}). ${doc.title}. ${detail.venue}.`;

  const copyCitation = () => {
    navigator.clipboard?.writeText(citation).catch(() => {});
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };

  const exportSummary = () => {
    const md = [
      `# ${doc.title}`,
      "",
      `**Topic:** ${doc.topic} · **Type:** ${doc.type} · **Source:** ${doc.source}`,
      `**Audience:** ${doc.audience} · **Added:** ${longDate(doc.date)} · **Status:** ${doc.status}`,
      "",
      "## AI summary",
      detail.shortSummary,
      "",
      "## Abstract",
      detail.abstract,
      "",
      "## Key findings",
      ...detail.keyFindings.map((f) => `- ${f}`),
      "",
      "## Outline",
      ...detail.sections.map((s) => `- ${s.title} (${s.pages} pp.)`),
      "",
      "## Citations",
      ...detail.citations.map((c) => `- ${c.authors} (${c.year}). ${c.title}. ${c.venue}.`),
    ].join("\n");
    const blob = new Blob([md], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${doc.id}-summary.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const ask = (q: string) => {
    const question = q.trim();
    if (!question) return;
    setThread((t) => [...t, { q: question, a: "", loading: true }]);
    setInput("");
    window.setTimeout(() => {
      setThread((t) =>
        t.map((m, i) =>
          i === t.length - 1 ? { ...m, a: freeformAnswer(doc, question), loading: false } : m
        )
      );
    }, 700);
    onAsk(doc);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true">
      <div
        className="absolute inset-0 bg-slate-900/50 backdrop-blur-[2px]"
        onClick={onClose}
        aria-hidden
      />

      <div
        ref={scrollRef}
        className="relative flex h-full w-full max-w-full flex-col overflow-y-auto border-l border-slate-200 bg-white shadow-2xl sm:w-[600px] dark:border-slate-800 dark:bg-slate-950"
        style={{ animation: "slideInRight 0.28s cubic-bezier(0.22,1,0.36,1) both" }}
      >
        {/* header */}
        <div className="sticky top-0 z-10 border-b border-slate-200 bg-white/95 px-5 py-4 backdrop-blur dark:border-slate-800 dark:bg-slate-950/95">
          <div className="flex items-start justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span
                className="rounded-md px-2 py-0.5 text-[11px] font-bold"
                style={{ background: `${color}18`, color }}
              >
                {doc.type}
              </span>
              <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                {doc.source}
              </span>
              <span
                className={`rounded-md px-2 py-0.5 text-[11px] font-semibold ${STATUS_STYLE[doc.status]}`}
              >
                {doc.status}
              </span>
            </div>
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
              aria-label="Close document"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <h2 className="mt-3 text-[19px] font-bold leading-snug tracking-tight text-slate-900 dark:text-white">
            {doc.title}
          </h2>
          <p className="mt-1.5 text-[12px] text-slate-500 dark:text-slate-400">
            {detail.authors.join(", ")} · {detail.venue} {detail.year}
          </p>
          <p className="mt-0.5 text-[12px] text-slate-400">
            {doc.topic} · {doc.id} · added {longDate(doc.date)} · {detail.readingMinutes} min read
          </p>

          <div className="mt-3 flex flex-wrap gap-2">
            <button
              onClick={() => setShowOutline((s) => !s)}
              className="flex h-8 items-center gap-1.5 rounded-lg bg-slate-900 px-3 text-[12px] font-semibold text-white transition-colors hover:bg-slate-700 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200"
            >
              <FileText className="h-3.5 w-3.5" />
              {showOutline ? "Hide outline" : "Open in reader"}
            </button>
            <button
              onClick={copyCitation}
              className="flex h-8 items-center gap-1.5 rounded-lg border border-slate-200 px-3 text-[12px] font-semibold text-slate-600 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? "Copied" : "Cite"}
            </button>
            <button
              onClick={() => setSaved((s) => !s)}
              className={`flex h-8 items-center gap-1.5 rounded-lg border px-3 text-[12px] font-semibold transition-colors ${
                saved
                  ? "border-indigo-300 bg-indigo-50 text-indigo-600 dark:border-indigo-500/40 dark:bg-indigo-500/15 dark:text-indigo-300"
                  : "border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              }`}
            >
              <BookMarked className="h-3.5 w-3.5" />
              {saved ? "Saved" : "Save"}
            </button>
            <button
              onClick={exportSummary}
              className="flex h-8 items-center gap-1.5 rounded-lg border border-slate-200 px-3 text-[12px] font-semibold text-slate-600 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              <Download className="h-3.5 w-3.5" />
              Summary
            </button>
          </div>
        </div>

        <div className="space-y-5 px-5 pb-10 pt-4">
          {/* stats */}
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[
              { l: "Questions", v: nf.format(doc.questions), i: MessagesSquare, c: "#06b6d4" },
              { l: "Time saved", v: `${doc.minutesSaved}m`, i: Clock, c: "#f59e0b" },
              { l: "Citations", v: nf.format(doc.citations), i: Quote, c: "#8b5cf6" },
              {
                l: "Confidence",
                v: `${(doc.confidence * 100).toFixed(0)}%`,
                i: Sparkles,
                c: doc.confidence > 0.92 ? "#10b981" : "#6366f1",
              },
            ].map((s) => (
              <div
                key={s.l}
                className="rounded-xl border border-slate-200 bg-slate-50/60 p-3 dark:border-slate-800 dark:bg-slate-900/60"
              >
                <s.i className="h-3.5 w-3.5" style={{ color: s.c }} />
                <p className="mt-1.5 text-[17px] font-bold leading-none tabular-nums text-slate-900 dark:text-white">
                  {s.v}
                </p>
                <p className="mt-1 text-[10px] uppercase tracking-wide text-slate-400">{s.l}</p>
              </div>
            ))}
          </div>

          {/* AI summary */}
          <section className="rounded-xl border border-indigo-200/70 bg-gradient-to-br from-indigo-50 to-white p-4 dark:border-indigo-500/25 dark:from-indigo-500/10 dark:to-slate-900">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-indigo-500" />
              <h3 className="text-[13px] font-bold text-slate-900 dark:text-white">AI summary</h3>
              <span className="ml-auto rounded-md bg-white/70 px-1.5 py-0.5 text-[10px] font-semibold text-indigo-600 dark:bg-indigo-500/20 dark:text-indigo-300">
                grounded · {(doc.confidence * 100).toFixed(0)}% confidence
              </span>
            </div>
            <p className="mt-2.5 text-[13px] leading-relaxed text-slate-700 dark:text-slate-200">
              {detail.shortSummary}
            </p>
            <p className="mt-2 text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">
              {detail.abstract}
            </p>
          </section>

          {/* key findings */}
          <section>
            <h3 className="mb-2 flex items-center gap-2 text-[13px] font-bold text-slate-900 dark:text-white">
              <Sparkles className="h-3.5 w-3.5 text-amber-500" />
              Key findings
            </h3>
            <ul className="space-y-2">
              {detail.keyFindings.map((f, i) => (
                <li key={i} className="flex gap-2.5">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-slate-100 text-[11px] font-bold text-slate-500 dark:bg-slate-800 dark:text-slate-300">
                    {i + 1}
                  </span>
                  <p className="text-[12.5px] leading-relaxed text-slate-600 dark:text-slate-300">
                    {f}
                  </p>
                </li>
              ))}
            </ul>
          </section>

          {/* outline */}
          {showOutline && (
            <section className="animate-fade-up rounded-xl border border-slate-200 p-4 dark:border-slate-800">
              <h3 className="mb-2 flex items-center gap-2 text-[13px] font-bold text-slate-900 dark:text-white">
                <ListTree className="h-3.5 w-3.5 text-slate-400" />
                Document outline
              </h3>
              <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                {detail.sections.map((s) => (
                  <li
                    key={s.title}
                    className="flex items-center justify-between py-1.5 text-[12.5px] text-slate-600 dark:text-slate-300"
                  >
                    <span>{s.title}</span>
                    <span className="text-[11px] tabular-nums text-slate-400">{s.pages} pp.</span>
                  </li>
                ))}
              </ul>
              <div className="mt-3 flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-[11px] text-slate-500 dark:bg-slate-800/60 dark:text-slate-400">
                <span>
                  {doc.pages} pages · {nf.format(doc.tokens)} tokens · {doc.audience}
                </span>
                <button
                  onClick={() => {
                    setShowOutline(false);
                    ask("Summarise section 3 in five bullets");
                  }}
                  className="flex items-center gap-1 font-semibold text-indigo-600 dark:text-indigo-400"
                >
                  Summarise section 3 <ArrowUpRight className="h-3 w-3" />
                </button>
              </div>
            </section>
          )}

          {/* engagement */}
          <section className="rounded-xl border border-slate-200 p-4 dark:border-slate-800">
            <div className="flex items-baseline justify-between">
              <h3 className="text-[13px] font-bold text-slate-900 dark:text-white">
                Questions over the last 30 days
              </h3>
              <span className="text-[11px] text-slate-400">
                {nf.format(detail.engagement.reduce((a, b) => a + b, 0))} total
              </span>
            </div>
            <div className="mt-2">
              <Sparkline values={detail.engagement} color="#06b6d4" height={54} />
            </div>
            <div className="mt-1 flex justify-between text-[10px] text-slate-400">
              <span>30 days ago</span>
              <span>today</span>
            </div>
          </section>

          {/* ask */}
          <section className="rounded-xl border border-slate-200 p-4 dark:border-slate-800">
            <h3 className="flex items-center gap-2 text-[13px] font-bold text-slate-900 dark:text-white">
              <MessagesSquare className="h-3.5 w-3.5 text-cyan-500" />
              Ask this document
            </h3>
            <div className="mt-2.5 flex flex-wrap gap-1.5">
              {detail.faq.map((f) => (
                <button
                  key={f.q}
                  onClick={() => ask(f.q)}
                  className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-[11px] font-medium text-slate-600 transition-colors hover:border-indigo-300 hover:text-indigo-600 dark:border-slate-700 dark:text-slate-300 dark:hover:border-indigo-500/50 dark:hover:text-indigo-300"
                >
                  {f.q}
                </button>
              ))}
            </div>

            {thread.map((m, i) => (
              <div key={i} className="mt-3 space-y-2">
                <div className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-br-sm bg-slate-900 px-3 py-2 text-[12.5px] text-white dark:bg-indigo-500">
                  {m.q}
                </div>
                <div className="rounded-2xl rounded-bl-sm bg-slate-100 px-3 py-2.5 text-[12.5px] leading-relaxed text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                  {m.loading ? (
                    <span className="flex items-center gap-2 text-slate-400">
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      Retrieving passages and drafting an answer…
                    </span>
                  ) : (
                    m.a
                  )}
                </div>
              </div>
            ))}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                ask(input);
              }}
              className="mt-3 flex items-center gap-2"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask anything about this document…"
                className="h-9 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 text-[12.5px] outline-none transition-colors focus:border-indigo-400 focus:bg-white focus:ring-2 focus:ring-indigo-500/15 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
              />
              <button
                type="submit"
                disabled={!input.trim()}
                className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-900 text-white transition-opacity disabled:opacity-40 dark:bg-indigo-500"
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </form>
          </section>

          {/* entities */}
          <section>
            <h3 className="mb-2 flex items-center gap-2 text-[13px] font-bold text-slate-900 dark:text-white">
              <Tag className="h-3.5 w-3.5 text-slate-400" />
              Extracted entities
            </h3>
            <div className="flex flex-wrap gap-1.5">
              {detail.entities.map((e) => (
                <span
                  key={e}
                  className="rounded-md bg-slate-100 px-2 py-1 text-[11px] font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300"
                >
                  {e}
                </span>
              ))}
            </div>
          </section>

          {/* citations */}
          <section>
            <h3 className="mb-2 flex items-center gap-2 text-[13px] font-bold text-slate-900 dark:text-white">
              <Quote className="h-3.5 w-3.5 text-violet-500" />
              Verified citations ({nf.format(doc.citations)})
            </h3>
            <ul className="divide-y divide-slate-100 dark:divide-slate-800">
              {detail.citations.map((c, i) => (
                <li key={i} className="py-2">
                  <p className="text-[12.5px] font-medium text-slate-700 dark:text-slate-200">
                    {c.title}
                  </p>
                  <p className="mt-0.5 text-[11px] text-slate-400">
                    {c.authors} · {c.venue} {c.year}
                  </p>
                </li>
              ))}
            </ul>
          </section>

          {/* related */}
          {related.length > 0 && (
            <section>
              <h3 className="mb-2 text-[13px] font-bold text-slate-900 dark:text-white">
                More on {doc.topic}
              </h3>
              <ul className="space-y-1.5">
                {related.map((r) => (
                  <li key={r.id + r.ts}>
                    <button
                      onClick={() => onOpenOther(r)}
                      className="group flex w-full items-start gap-2.5 rounded-xl border border-slate-200 p-3 text-left transition-colors hover:border-indigo-300 hover:bg-slate-50 dark:border-slate-800 dark:hover:border-indigo-500/40 dark:hover:bg-slate-800/60"
                    >
                      <span
                        className="mt-1.5 h-2 w-2 shrink-0 rounded-full"
                        style={{ background: TYPE_COLOR[r.type] }}
                      />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[12.5px] font-medium text-slate-800 group-hover:text-indigo-600 dark:text-slate-100 dark:group-hover:text-indigo-300">
                          {r.title}
                        </span>
                        <span className="mt-0.5 block text-[11px] text-slate-400">
                          {r.type} · {r.source} · {longDate(r.date)}
                        </span>
                      </span>
                      <ArrowUpRight className="mt-1 h-3.5 w-3.5 shrink-0 text-slate-300 group-hover:text-indigo-500" />
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
