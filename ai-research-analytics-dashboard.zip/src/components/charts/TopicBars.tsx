import { compact, type Bucket } from "../../lib/data";

export default function TopicBars({ data, dark }: { data: Bucket[]; dark: boolean }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  const total = data.reduce((a, b) => a + b.value, 0) || 1;

  return (
    <ul className="space-y-2.5">
      {data.map((t, i) => {
        const share = (t.value / total) * 100;
        return (
          <li key={t.key} className="group">
            <div className="mb-1 flex items-baseline justify-between gap-3">
              <span className="truncate text-[13px] font-medium text-slate-600 dark:text-slate-300">
                {t.label}
              </span>
              <span className="shrink-0 text-[12px] font-semibold tabular-nums text-slate-900 dark:text-white">
                {compact(t.value)}
                <span className="ml-1.5 font-normal text-slate-400">{share.toFixed(1)}%</span>
              </span>
            </div>
            <div
              className="h-2 w-full overflow-hidden rounded-full"
              style={{ background: dark ? "#1e293b" : "#eef1f7" }}
            >
              <div
                className="h-full rounded-full transition-all duration-700 ease-out group-hover:brightness-110"
                style={{
                  width: `${Math.max(2, (t.value / max) * 100)}%`,
                  background: `linear-gradient(90deg, ${t.color}, ${t.color}bb)`,
                  transitionDelay: `${i * 45}ms`,
                }}
              />
            </div>
          </li>
        );
      })}
    </ul>
  );
}
