import { useCallback, useEffect, useState } from "react";

export type Theme = "light" | "dark";

function initial(): Theme {
  if (typeof window === "undefined") return "light";
  const stored = window.localStorage.getItem("cortex-theme");
  if (stored === "light" || stored === "dark") return stored;
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(initial);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    root.style.colorScheme = theme;
    window.localStorage.setItem("cortex-theme", theme);
  }, [theme]);

  const toggle = useCallback(() => setTheme((t) => (t === "dark" ? "light" : "dark")), []);
  return { theme, setTheme, toggle, dark: theme === "dark" };
}

export const SERIES = [
  "#6366f1",
  "#06b6d4",
  "#f59e0b",
  "#ec4899",
  "#10b981",
  "#8b5cf6",
  "#ef4444",
  "#3b82f6",
];

export function chartTheme(dark: boolean) {
  return {
    grid: dark ? "#1e293b" : "#e9edf5",
    axis: dark ? "#64748b" : "#94a3b8",
    tooltipBg: dark ? "#0f172a" : "#ffffff",
    tooltipBorder: dark ? "#1e293b" : "#e2e8f0",
    tooltipText: dark ? "#e2e8f0" : "#0f172a",
    cursor: dark ? "rgba(148,163,184,0.14)" : "rgba(100,116,139,0.10)",
  };
}
