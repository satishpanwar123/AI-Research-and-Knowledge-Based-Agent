import { useEffect, useRef, useState } from "react";
import { Check, ChevronDown } from "lucide-react";

type Props = {
  label: string;
  icon?: React.ReactNode;
  options: readonly string[];
  selected: string[];
  onChange: (next: string[]) => void;
  accent?: string;
};

export default function MultiSelect({
  label,
  icon,
  options,
  selected,
  onChange,
  accent = "#6366f1",
}: Props) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onEsc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onEsc);
    };
  }, [open]);

  const all = selected.length === options.length;
  const toggle = (opt: string) =>
    onChange(selected.includes(opt) ? selected.filter((s) => s !== opt) : [...selected, opt]);

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={`flex h-9 w-full items-center gap-2 rounded-lg border px-3 text-sm font-medium transition-colors sm:w-auto ${
          all
            ? "border-slate-200 bg-white text-slate-600 hover:border-slate-300 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:border-slate-600"
            : "text-slate-800 dark:text-white"
        }`}
        style={
          all
            ? undefined
            : { borderColor: accent, background: `${accent}14`, boxShadow: `0 0 0 3px ${accent}14` }
        }
        aria-expanded={open}
      >
        {icon}
        <span className="whitespace-nowrap">{label}</span>
        <span
          className="ml-0.5 rounded-md px-1.5 py-0.5 text-[11px] font-semibold tabular-nums"
          style={
            all
              ? undefined
              : { background: `${accent}26`, color: "inherit" }
          }
        >
          {all ? "All" : selected.length}
        </span>
        <ChevronDown
          className={`ml-auto h-4 w-4 opacity-60 transition-transform duration-200 ${
            open ? "rotate-180" : ""
          }`}
        />
      </button>

      {open && (
        <div className="absolute right-0 z-40 mt-2 w-60 animate-pop overflow-hidden rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl shadow-slate-900/10 dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/50">
          <div className="flex items-center justify-between px-2 py-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              {label}
            </span>
            <div className="flex gap-1">
              <button
                onClick={() => onChange([...options])}
                className="rounded px-1.5 py-0.5 text-[11px] font-medium text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-500/10"
              >
                All
              </button>
              <button
                onClick={() => onChange([])}
                className="rounded px-1.5 py-0.5 text-[11px] font-medium text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                None
              </button>
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto">
            {options.map((opt) => {
              const on = selected.includes(opt);
              return (
                <button
                  key={opt}
                  onClick={() => toggle(opt)}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-left text-sm text-slate-700 transition-colors hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <span
                    className="flex h-4 w-4 shrink-0 items-center justify-center rounded-[5px] border transition-colors"
                    style={{
                      background: on ? accent : "transparent",
                      borderColor: on ? accent : "currentColor",
                      color: on ? "#fff" : undefined,
                    }}
                  >
                    {on && <Check className="h-3 w-3" strokeWidth={3.2} />}
                  </span>
                  <span className="truncate">{opt}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
