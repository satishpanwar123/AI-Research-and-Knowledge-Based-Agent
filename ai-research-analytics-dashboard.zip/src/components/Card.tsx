import type { ReactNode } from "react";

export default function Card({
  title,
  subtitle,
  actions,
  children,
  className = "",
  delay = 0,
  bodyClass = "",
}: {
  title?: string;
  subtitle?: string;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  delay?: number;
  bodyClass?: string;
}) {
  return (
    <section
      className={`animate-fade-up rounded-2xl border border-slate-200 bg-white p-4 shadow-sm shadow-slate-900/[0.03] transition-colors sm:p-5 dark:border-slate-800 dark:bg-slate-900/60 dark:shadow-black/20 ${className}`}
      style={{ animationDelay: `${delay}ms` }}
    >
      {(title || actions) && (
        <header className="mb-4 flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            {title && (
              <h3 className="text-[15px] font-semibold tracking-tight text-slate-900 dark:text-white">
                {title}
              </h3>
            )}
            {subtitle && (
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>
            )}
          </div>
          {actions}
        </header>
      )}
      <div className={bodyClass}>{children}</div>
    </section>
  );
}

export function Chip({
  children,
  color = "#6366f1",
  onClick,
  active,
}: {
  children: ReactNode;
  color?: string;
  onClick?: () => void;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className="rounded-md px-2 py-1 text-[11px] font-semibold transition-colors"
      style={{
        background: active ? color : `${color}18`,
        color: active ? "#fff" : color,
      }}
    >
      {children}
    </button>
  );
}
