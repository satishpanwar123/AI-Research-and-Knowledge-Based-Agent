/* ------------------------------------------------------------------
   Synthetic analytics engine for "Cortex" — an AI research &
   knowledge-management workspace.

   Everything is generated from a fixed seed so the dashboard is
   stable across reloads, but rich enough that every chart reacts
   to the date-range + segment filters.
------------------------------------------------------------------- */

export const AUDIENCES = [
  "Students",
  "Researchers",
  "Developers",
  "Teachers",
  "Professionals",
] as const;
export type Audience = (typeof AUDIENCES)[number];

export const DOC_TYPES = [
  "Research Paper",
  "PDF Report",
  "Technical Doc",
  "Article / Blog",
  "Lecture Slides",
] as const;
export type DocType = (typeof DOC_TYPES)[number];

export const SOURCES = ["arXiv", "PubMed", "Internal Wiki", "Web", "GitHub"] as const;
export type Source = (typeof SOURCES)[number];

export const STATUSES = ["Indexed", "Processing", "Needs Review", "Archived"] as const;
export type Status = (typeof STATUSES)[number];

const NA = AUDIENCES.length; // 5
const NS = SOURCES.length; // 5
export const COMBOS = DOC_TYPES.length * NA * NS; // 125

/* ------------------------------ RNG ------------------------------ */
function mulberry32(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function noise(...nums: number[]) {
  let h = 0x811c9dc5;
  for (const n of nums) {
    h ^= Math.imul(n + 0x9e3779b9, 0x85ebca6b) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  }
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

/* ---------------------------- weights ---------------------------- */
// index order for combos: docType -> audience -> source
const AU_W = [0.27, 0.25, 0.2, 0.11, 0.17];
const DT_W = [0.31, 0.21, 0.19, 0.19, 0.1];
const SO_W = [0.24, 0.15, 0.22, 0.26, 0.13];

export const comboIndex = (dt: number, au: number, so: number) =>
  (dt * NA + au) * NS + so;
export const decodeCombo = (i: number) => {
  const so = i % NS;
  const au = Math.floor(i / NS) % NA;
  const dt = Math.floor(i / (NS * NA));
  return { dt, au, so };
};

/* ---------------------------- calendar --------------------------- */
export const DAYS = 365;
const DAY_MS = 86400000;

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

// The dataset always ends "today" so the demo never goes stale.
const TODAY = startOfDay(new Date());
export const DATA_START = new Date(TODAY.getTime() - (DAYS - 1) * DAY_MS);
export const DATA_END = TODAY;
export const isoOf = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
export const isoToDate = (iso: string) => {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
};

/* -------------------------- day records -------------------------- */
export type Day = {
  iso: string;
  ts: number;
  dow: number; // 0 = Sunday
  docs: Float64Array;
  queries: Float64Array;
  summaries: Float64Array;
  citations: Float64Array;
  timeSaved: Float64Array; // minutes
  users: Float64Array; // active users (fractional share)
  quality: Float64Array; // mean answer confidence 0..1
};

function buildDays(): Day[] {
  const days: Day[] = [];
  const raw = new Float64Array(COMBOS);

  for (let i = 0; i < DAYS; i++) {
    const date = new Date(DATA_START.getTime() + i * DAY_MS);
    const dow = date.getDay();
    const t = i / (DAYS - 1);

    // adoption S-curve + academic seasonality + weekly rhythm + noise
    const growth = 0.52 + 1.0 / (1 + Math.exp(-(t - 0.42) * 4.1));
    const season = 1 + 0.13 * Math.sin(t * Math.PI * 2 * 1.7 - 0.7) + 0.05 * Math.sin(t * Math.PI * 6);
    const weekly = dow === 0 ? 0.55 : dow === 6 ? 0.62 : dow === 5 ? 0.88 : dow === 1 ? 1.08 : 1;
    const wobble = 0.9 + 0.2 * noise(i, 11);

    const dayDocs = 560 * growth * season * weekly * wobble;
    const qpd = 3.0 + 2.9 * t + 0.35 * Math.sin(t * 9); // questions per document
    const spd = 0.6 + 0.22 * t; // summaries per document
    const cpd = 7.4 + 3.2 * t; // citations captured per document
    const mpd = 18.5 + 7.5 * t; // minutes saved per document
    const dayUsers = (620 + 2700 * t) * (0.62 + 0.38 * weekly) * (0.94 + 0.12 * noise(i, 29));
    const baseQuality = Math.min(0.968, Math.max(0.83, 0.878 + 0.052 * t + 0.012 * Math.sin(t * 12)));

    let total = 0;
    for (let c = 0; c < COMBOS; c++) {
      const { dt, au, so } = decodeCombo(c);
      const w =
        DT_W[dt] * AU_W[au] * SO_W[so] * (0.5 + 1.05 * noise(i * 7 + c, dt * 31 + au * 17 + so));
      raw[c] = w;
      total += w;
    }

    const docs = new Float64Array(COMBOS);
    const queries = new Float64Array(COMBOS);
    const summaries = new Float64Array(COMBOS);
    const citations = new Float64Array(COMBOS);
    const timeSaved = new Float64Array(COMBOS);
    const users = new Float64Array(COMBOS);
    const quality = new Float64Array(COMBOS);

    for (let c = 0; c < COMBOS; c++) {
      const w = raw[c] / total;
      const j = noise(c * 13, i * 3);
      docs[c] = dayDocs * w;
      queries[c] = docs[c] * qpd * (0.78 + 0.44 * j);
      summaries[c] = docs[c] * spd * (0.8 + 0.4 * noise(c, i * 5 + 1));
      citations[c] = docs[c] * cpd * (0.75 + 0.5 * noise(c * 3, i * 2 + 4));
      timeSaved[c] = docs[c] * mpd * (0.82 + 0.36 * noise(c * 5, i + 8));
      users[c] = dayUsers * w;
      quality[c] = Math.min(0.985, Math.max(0.78, baseQuality + (j - 0.5) * 0.062));
    }

    days.push({
      iso: isoOf(date),
      ts: date.getTime(),
      dow,
      docs,
      queries,
      summaries,
      citations,
      timeSaved,
      users,
      quality,
    });
  }
  return days;
}

export const DAY_DATA: Day[] = buildDays();
export const DAY_INDEX: Record<string, number> = Object.fromEntries(
  DAY_DATA.map((d, i) => [d.iso, i])
);

/* --------------------------- documents --------------------------- */
export type Topic = {
  name: string;
  base: number;
  color: string;
  dtAff: number[]; // per DOC_TYPES
  auAff: number[]; // per AUDIENCES
};

export const TOPICS: Topic[] = [
  { name: "NLP & Large Language Models", base: 0.245, color: "#6366f1", dtAff: [1.25, 0.7, 1.1, 1.4, 0.85], auAff: [1.0, 1.15, 1.55, 0.75, 1.1] },
  { name: "Machine Learning Theory", base: 0.185, color: "#06b6d4", dtAff: [1.3, 0.75, 0.85, 0.9, 1.25], auAff: [1.2, 1.3, 0.95, 1.05, 0.85] },
  { name: "Computer Vision", base: 0.15, color: "#f59e0b", dtAff: [1.2, 0.85, 1.0, 0.8, 1.1], auAff: [0.95, 1.1, 1.25, 0.8, 0.95] },
  { name: "Bioinformatics & Medicine", base: 0.125, color: "#10b981", dtAff: [1.15, 1.35, 0.6, 0.7, 0.8], auAff: [0.9, 1.5, 0.6, 0.9, 1.15] },
  { name: "Human–Computer Interaction", base: 0.095, color: "#ec4899", dtAff: [0.95, 0.7, 1.1, 1.0, 1.3], auAff: [1.05, 0.9, 1.2, 1.35, 1.0] },
  { name: "Robotics & Control", base: 0.08, color: "#8b5cf6", dtAff: [1.05, 0.9, 1.3, 0.6, 0.95], auAff: [0.9, 1.15, 1.35, 0.75, 0.9] },
  { name: "Climate & Energy Systems", base: 0.07, color: "#22c55e", dtAff: [1.0, 1.45, 0.8, 0.85, 0.7], auAff: [0.95, 1.25, 0.7, 1.1, 1.2] },
  { name: "AI Policy & Economics", base: 0.05, color: "#f43f5e", dtAff: [0.8, 1.3, 0.6, 1.35, 1.0], auAff: [0.9, 0.85, 0.8, 1.2, 1.6] },
];

const TITLE_BANK: Record<string, string[]> = {
  "NLP & Large Language Models": [
    "Retrieval-Augmented Generation for Long-Context Question Answering",
    "Instruction Tuning with Sparse Mixture-of-Experts Adapters",
    "Evaluating Hallucination Rates in Domain-Specific Chat Assistants",
    "Dense Passage Retrieval at Web Scale: A Reproducibility Study",
    "Chain-of-Thought Distillation for Small Language Models",
  ],
  "Machine Learning Theory": [
    "Generalization Bounds for Over-Parameterized Transformer Models",
    "On the Implicit Bias of Gradient Descent in Deep Linear Networks",
    "Spectral Methods for Efficient Kernel Approximation",
    "Sharpness-Aware Minimization Revisited: Theory and Practice",
    "A Unified View of Contrastive and Supervised Representation Learning",
  ],
  "Computer Vision": [
    "Segment Anything in the Wild: Zero-Shot Transfer Benchmarks",
    "Diffusion Priors for Single-Image 3D Reconstruction",
    "Self-Supervised Video Representation Learning at Scale",
    "Robust Object Detection Under Distribution Shift",
    "Neural Radiance Fields for Real-Time Scene Editing",
  ],
  "Bioinformatics & Medicine": [
    "Protein Structure Prediction Beyond the Fold Universe",
    "Federated Learning Across Hospital Networks: A Clinical Validation",
    "Single-Cell Atlas Integration with Graph Neural Networks",
    "Radiology Report Summarization Using Clinical Foundation Models",
    "Drug–Target Interaction Prediction with Multi-Modal Embeddings",
  ],
  "Human–Computer Interaction": [
    "Designing Copilots: Measuring Cognitive Load in AI-Assisted Writing",
    "Prompting Interfaces for Non-Expert Users in Knowledge Work",
    "Trust Calibration in Conversational Research Assistants",
    "Eye-Tracking Study of Document Summarization Interfaces",
    "Collaborative Annotation Tools for Distributed Research Teams",
  ],
  "Robotics & Control": [
    "Sim-to-Real Transfer for Legged Locomotion Policies",
    "Vision-Language-Action Models for Household Manipulation",
    "Safe Reinforcement Learning with Learned Constraint Models",
    "Tactile Sensing for Dexterous In-Hand Reorientation",
    "Multi-Robot Coordination Under Partial Observability",
  ],
  "Climate & Energy Systems": [
    "Machine Learning Emulators for Regional Climate Downscaling",
    "Grid Load Forecasting with Spatio-Temporal Transformers",
    "Satellite Imagery Fusion for Methane Leak Detection",
    "Probabilistic Wind Power Forecasting Under Extreme Weather",
    "Carbon-Aware Scheduling for Large-Scale Model Training",
  ],
  "AI Policy & Economics": [
    "Measuring Automation Exposure Across Knowledge Occupations",
    "Compute Governance: Auditing Frontier Model Training Runs",
    "Copyright and Fair Use in Generative Training Corpora",
    "Productivity Effects of Generative Assistants: A Field Experiment",
    "Regulatory Sandboxes for High-Risk AI Systems",
  ],
};

const SUFFIX = [
  "",
  "",
  "",
  " — v2",
  " (Preprint)",
  " — Extended Version",
  ", Ch. 4: Method",
  " (Camera Ready)",
  " — Replication Package",
];

export type Doc = {
  id: string;
  title: string;
  topic: string;
  type: DocType;
  audience: Audience;
  source: Source;
  date: string;
  ts: number;
  pages: number;
  tokens: number;
  questions: number;
  summaries: number;
  citations: number;
  minutesSaved: number;
  confidence: number;
  status: Status;
  lastOpened: string;
};

function pickWeighted(w: number[], r: number) {
  let acc = 0;
  const total = w.reduce((a, b) => a + b, 0);
  for (let i = 0; i < w.length; i++) {
    acc += w[i] / total;
    if (r <= acc) return i;
  }
  return w.length - 1;
}

function buildDocuments(): Doc[] {
  const rnd = mulberry32(20260215);
  const docs: Doc[] = [];
  const count = 340;

  for (let i = 0; i < count; i++) {
    const r = rnd();
    // recency bias: newer documents are more common
    const dayIdx = Math.min(DAYS - 1, Math.floor(Math.pow(rnd(), 0.62) * DAYS));
    const day = DAY_DATA[dayIdx];
    const t = dayIdx / (DAYS - 1);

    const dt = pickWeighted(DT_W, rnd());
    const au = pickWeighted(AU_W, rnd());
    const so = pickWeighted(SO_W, rnd());
    const ci = comboIndex(dt, au, so);

    // topic affinity given doc type + audience
    const tw = TOPICS.map(
      (tp) => tp.base * tp.dtAff[dt] * tp.auAff[au] * (0.6 + 0.8 * rnd())
    );
    let acc = 0;
    const tTotal = tw.reduce((a, b) => a + b, 0);
    const rr = rnd() * tTotal;
    let topicIdx = 0;
    for (let k = 0; k < tw.length; k++) {
      acc += tw[k];
      if (rr <= acc) {
        topicIdx = k;
        break;
      }
    }
    const topic = TOPICS[topicIdx].name;

    const bank = TITLE_BANK[topic];
    const title = bank[Math.floor(rnd() * bank.length)] + SUFFIX[Math.floor(rnd() * SUFFIX.length)];

    const pages = Math.max(3, Math.round(6 + rnd() * (dt === 4 ? 46 : dt === 0 ? 34 : 62)));
    const tokens = Math.round(pages * (430 + rnd() * 160));
    const factor = 0.35 + rnd() * 2.4;

    const statusRoll = rnd();
    const daysSince = Math.floor(rnd() * 9);
    docs.push({
      id: `DOC-${(1042 + i * 7).toString()}-${(dt + 1) * 13 + au}`,
      title,
      topic,
      type: DOC_TYPES[dt],
      audience: AUDIENCES[au],
      source: SOURCES[so],
      date: day.iso,
      ts: day.ts,
      pages,
      tokens,
      questions: Math.max(1, Math.round(day.queries[ci] * factor * 0.02)),
      summaries: Math.max(0, Math.round(day.summaries[ci] * factor * 0.02)),
      citations: Math.max(0, Math.round(day.citations[ci] * factor * 0.02)),
      minutesSaved: Math.round(day.timeSaved[ci] * factor * 0.02),
      confidence: Math.min(0.99, Math.max(0.7, day.quality[ci] + (rnd() - 0.5) * 0.06)),
      status:
        statusRoll < 0.72
          ? "Indexed"
          : statusRoll < 0.83
          ? "Processing"
          : statusRoll < 0.94
          ? "Needs Review"
          : "Archived",
      lastOpened: isoOf(new Date(day.ts - daysSince * DAY_MS)),
    });
    void r;
    void t;
  }
  return docs.sort((a, b) => b.ts - a.ts);
}

export const DOCUMENTS: Doc[] = buildDocuments();

/* --------------------------- aggregation -------------------------- */
export type Point = {
  iso: string;
  ts: number;
  dow: number;
  docs: number;
  queries: number;
  summaries: number;
  citations: number;
  timeSaved: number;
  users: number;
  quality: number;
};

export function buildCombos(
  docTypes: string[],
  audiences: string[],
  sources: string[]
): number[] {
  const out: number[] = [];
  for (let dt = 0; dt < DOC_TYPES.length; dt++) {
    if (!docTypes.includes(DOC_TYPES[dt])) continue;
    for (let au = 0; au < NA; au++) {
      if (!audiences.includes(AUDIENCES[au])) continue;
      for (let so = 0; so < NS; so++) {
        if (!sources.includes(SOURCES[so])) continue;
        out.push(comboIndex(dt, au, so));
      }
    }
  }
  return out;
}

export function seriesFor(from: number, to: number, combos: number[]): Point[] {
  const out: Point[] = [];
  for (let i = from; i <= to; i++) {
    const d = DAY_DATA[i];
    let docs = 0,
      queries = 0,
      summaries = 0,
      citations = 0,
      timeSaved = 0,
      users = 0,
      qw = 0;
    for (let k = 0; k < combos.length; k++) {
      const c = combos[k];
      docs += d.docs[c];
      queries += d.queries[c];
      summaries += d.summaries[c];
      citations += d.citations[c];
      timeSaved += d.timeSaved[c];
      users += d.users[c];
      qw += d.quality[c] * d.docs[c];
    }
    out.push({
      iso: d.iso,
      ts: d.ts,
      dow: d.dow,
      docs,
      queries,
      summaries,
      citations,
      timeSaved,
      users,
      quality: docs > 0 ? qw / docs : 0,
    });
  }
  return out;
}

export function summarize(points: Point[]) {
  const t = points.reduce(
    (a, p) => {
      a.docs += p.docs;
      a.queries += p.queries;
      a.summaries += p.summaries;
      a.citations += p.citations;
      a.timeSaved += p.timeSaved;
      a.users += p.users;
      a.qw += p.quality * p.docs;
      return a;
    },
    { docs: 0, queries: 0, summaries: 0, citations: 0, timeSaved: 0, users: 0, qw: 0 }
  );
  return {
    docs: t.docs,
    queries: t.queries,
    summaries: t.summaries,
    citations: t.citations,
    hoursSaved: t.timeSaved / 60,
    activeUsers: points.length ? t.users / points.length : 0,
    quality: t.docs > 0 ? t.qw / t.docs : 0,
    queriesPerDoc: t.docs > 0 ? t.queries / t.docs : 0,
    minutesPerDoc: t.docs > 0 ? t.timeSaved / t.docs : 0,
    days: points.length,
  };
}

export type Bucket = { key: string; label: string; value: number; secondary: number; color?: string };

export function bucketBy(
  from: number,
  to: number,
  combos: number[],
  dim: "dt" | "au" | "so"
): Bucket[] {
  const labels = dim === "dt" ? DOC_TYPES : dim === "au" ? AUDIENCES : SOURCES;
  const size = labels.length;
  const acc = new Float64Array(size);
  const acc2 = new Float64Array(size);
  for (let i = from; i <= to; i++) {
    const d = DAY_DATA[i];
    for (const c of combos) {
      const idx = dim === "dt" ? decodeCombo(c).dt : dim === "au" ? decodeCombo(c).au : decodeCombo(c).so;
      acc[idx] += d.docs[c];
      acc2[idx] += d.queries[c];
    }
  }
  return labels.map((label, i) => ({
    key: label,
    label,
    value: acc[i],
    secondary: acc2[i],
    color: undefined,
  }));
}

export function weekdayBreakdown(points: Point[], audiences: string[]): Bucket[] {
  const names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  return names.map((n, i) => {
    const p = points.filter((x) => x.dow === i);
    return {
      key: n,
      label: n,
      value: p.reduce((a, b) => a + b.queries, 0) / Math.max(1, p.length),
      secondary: p.reduce((a, b) => a + b.docs, 0) / Math.max(1, p.length),
      color: undefined,
    };
  });
  void audiences;
}

export function topicBreakdown(totalDocs: number, docTypes: string[], audiences: string[]) {
  const dtIdx = DOC_TYPES.map((d, i) => (docTypes.includes(d) ? i : -1)).filter((i) => i >= 0);
  const auIdx = AUDIENCES.map((a, i) => (audiences.includes(a) ? i : -1)).filter((i) => i >= 0);
  const weights = TOPICS.map((tp) => {
    const dt = dtIdx.length ? dtIdx.reduce((a, i) => a + tp.dtAff[i], 0) / dtIdx.length : 1;
    const au = auIdx.length ? auIdx.reduce((a, i) => a + tp.auAff[i], 0) / auIdx.length : 1;
    return tp.base * dt * au;
  });
  const total = weights.reduce((a, b) => a + b, 0) || 1;
  return TOPICS.map((tp, i) => ({
    key: tp.name,
    label: tp.name,
    value: (totalDocs * weights[i]) / total,
    secondary: weights[i] / total,
    color: tp.color,
  })).sort((a, b) => b.value - a.value);
}

/* --------------------------- bucketing --------------------------- */
export function resample(points: Point[], gran: "day" | "week" | "month"): Point[] {
  if (gran === "day") return points;
  const map = new Map<string, Point[]>();
  for (const p of points) {
    const d = new Date(p.ts);
    const key =
      gran === "week"
        ? (() => {
            const s = new Date(d);
            s.setDate(d.getDate() - ((d.getDay() + 6) % 7));
            return isoOf(s);
          })()
        : `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(p);
  }
  return [...map.entries()].map(([key, arr]) => {
    const base: Point = { ...arr[0], iso: key, ts: isoToDate(key).getTime() };
    const sum = arr.reduce(
      (a, p) => {
        a.docs += p.docs;
        a.queries += p.queries;
        a.summaries += p.summaries;
        a.citations += p.citations;
        a.timeSaved += p.timeSaved;
        a.users += p.users;
        a.qw += p.quality * p.docs;
        return a;
      },
      { docs: 0, queries: 0, summaries: 0, citations: 0, timeSaved: 0, users: 0, qw: 0 }
    );
    base.docs = sum.docs;
    base.queries = sum.queries;
    base.summaries = sum.summaries;
    base.citations = sum.citations;
    base.timeSaved = sum.timeSaved;
    base.users = sum.users / arr.length;
    base.quality = sum.docs > 0 ? sum.qw / sum.docs : 0;
    return base;
  });
}

export function sparkline(points: Point[], key: keyof Point, max = 26) {
  if (!points.length) return [] as number[];
  const stride = Math.max(1, Math.floor(points.length / max));
  const out: number[] = [];
  for (let i = 0; i < points.length; i += stride) out.push(points[i][key] as number);
  if (out[out.length - 1] !== points[points.length - 1][key])
    out.push(points[points.length - 1][key] as number);
  return out;
}

/* ---------------------------- formatters -------------------------- */
export const nf = new Intl.NumberFormat("en-US");
export const nf1 = new Intl.NumberFormat("en-US", { maximumFractionDigits: 1 });
export function compact(n: number) {
  if (Math.abs(n) >= 1_000_000) return `${(n / 1_000_000).toFixed(Math.abs(n) >= 10_000_000 ? 0 : 1)}M`;
  if (Math.abs(n) >= 10_000) return `${(n / 1000).toFixed(0)}k`;
  if (Math.abs(n) >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return nf.format(Math.round(n));
}
export function pct(n: number, digits = 1) {
  return `${(n * 100).toFixed(digits)}%`;
}
export function shortDate(iso: string) {
  const d = isoToDate(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}
export function longDate(iso: string) {
  const d = isoToDate(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}
export function dayLabel(iso: string) {
  const d = isoToDate(iso);
  return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}
export function delta(curr: number, prev: number) {
  if (!prev) return 0;
  return (curr - prev) / prev;
}
