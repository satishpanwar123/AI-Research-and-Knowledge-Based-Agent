import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import ChartTooltip from "./ChartTooltip";
import { chartTheme } from "../../hooks/useTheme";
import { compact, dayLabel, shortDate, type Point } from "../../lib/data";

export type MetricKey = "docs" | "queries" | "timeSaved" | "users";

export const METRICS: { key: MetricKey; label: string; color: string; unit: string }[] = [
  { key: "docs", label: "Documents processed", color: "#6366f1", unit: "" },
  { key: "queries", label: "Questions answered", color: "#06b6d4", unit: "" },
  { key: "timeSaved", label: "Minutes saved", color: "#f59e0b", unit: "m" },
  { key: "users", label: "Active users", color: "#ec4899", unit: "" },
];

type Props = {
  points: Point[];
  prev: Point[];
  metric: MetricKey;
  dark: boolean;
  gran: "day" | "week" | "month";
};

const fmtValue = (metric: MetricKey, v: number) =>
  metric === "timeSaved" ? `${compact(v / 60)}h` : compact(v);

export default function ActivityTrend({ points, prev, metric, dark, gran }: Props) {
  const th = chartTheme(dark);
  const meta = METRICS.find((m) => m.key === metric)!;
  const data = points.map((p, i) => ({
    iso: p.iso,
    value: p[metric] as number,
    prevValue: prev[i] ? ((prev[i][metric] as number) ?? null) : null,
  }));

  const deltaAt = (i: number) => {
    const c = data[i]?.value ?? 0;
    const p = data[i]?.prevValue;
    if (!p) return null;
    return ((c - p) / p) * 100;
  };

  return (
    <ResponsiveContainer width="100%" height={292}>
      <ComposedChart data={data} margin={{ top: 8, right: 8, left: -14, bottom: 0 }}>
        <defs>
          <linearGradient id={`grad-${metric}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={meta.color} stopOpacity={0.42} />
            <stop offset="96%" stopColor={meta.color} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={th.grid} strokeDasharray="4 6" vertical={false} />
        <XAxis
          dataKey="iso"
          tickFormatter={(v: string) => (gran === "month" ? v.slice(0, 7) : shortDate(v))}
          tick={{ fill: th.axis, fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          minTickGap={28}
          dy={6}
        />
        <YAxis
          tickFormatter={(v: number) => (metric === "timeSaved" ? compact(v / 60) : compact(v))}
          tick={{ fill: th.axis, fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          width={58}
        />
        <Tooltip
          cursor={{ stroke: th.axis, strokeDasharray: "3 4", strokeWidth: 1 }}
          content={({ active, label, payload }: any) => {
            if (!active || !payload?.length || !label) return null;
            const i = payload[0]?.payload?.iso
              ? data.findIndex((d) => d.iso === payload[0].payload.iso)
              : -1;
            const d = deltaAt(i);
            return (
              <ChartTooltip
                dark={dark}
                subtitle={gran === "day" ? dayLabel(label) : "Period"}
                title={fmtValue(metric, data[i]?.value ?? 0)}
                rows={[
                  {
                    label: meta.label,
                    value: fmtValue(metric, data[i]?.value ?? 0),
                    color: meta.color,
                  },
                  ...(data[i]?.prevValue != null
                    ? [
                        {
                          label: "Previous period",
                          value: fmtValue(metric, data[i].prevValue as number),
                          color: dark ? "#64748b" : "#94a3b8",
                        },
                      ]
                    : []),
                ]}
                footer={
                  d == null ? undefined : (
                    <span
                      className="font-semibold"
                      style={{ color: d >= 0 ? "#10b981" : "#f43f5e" }}
                    >
                      {d >= 0 ? "▲" : "▼"} {Math.abs(d).toFixed(1)}% vs previous period
                    </span>
                  )
                }
              />
            );
          }}
        />
        <Area
          type="monotone"
          dataKey="value"
          stroke={meta.color}
          strokeWidth={2.4}
          fill={`url(#grad-${metric})`}
          animationDuration={750}
          activeDot={{
            r: 5,
            fill: meta.color,
            stroke: dark ? "#0f172a" : "#fff",
            strokeWidth: 2.5,
          }}
        />
        <Line
          type="monotone"
          dataKey="prevValue"
          stroke={dark ? "#64748b" : "#94a3b8"}
          strokeWidth={1.6}
          strokeDasharray="5 5"
          dot={false}
          animationDuration={750}
          connectNulls
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
