import type { ReactNode } from "react";

export type Row = {
  label: string;
  value: string;
  color: string;
  hint?: string;
};

export default function ChartTooltip({
  title,
  subtitle,
  rows,
  footer,
  dark,
}: {
  title: string;
  subtitle?: string;
  rows: Row[];
  footer?: ReactNode;
  dark: boolean;
}) {
  return (
    <div
      className="min-w-[168px] rounded-xl border px-3 py-2.5 shadow-xl backdrop-blur-sm"
      style={{
        background: dark ? "rgba(15,23,42,0.96)" : "rgba(255,255,255,0.98)",
        borderColor: dark ? "#1e293b" : "#e2e8f0",
        boxShadow: dark
          ? "0 18px 40px -12px rgba(0,0,0,0.9)"
          : "0 18px 40px -14px rgba(15,23,42,0.28)",
      }}
    >
      {subtitle && (
        <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
          {subtitle}
        </p>
      )}
      <p
        className="text-[13px] font-semibold"
        style={{ color: dark ? "#f1f5f9" : "#0f172a" }}
      >
        {title}
      </p>
      <div className="mt-2 space-y-1.5">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center justify-between gap-4 text-[12px]">
            <span className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
              <span
                className="h-2 w-2 shrink-0 rounded-full"
                style={{ background: r.color }}
              />
              {r.label}
            </span>
            <span className="font-semibold tabular-nums text-slate-800 dark:text-slate-100">
              {r.value}
              {r.hint && (
                <span className="ml-1 font-normal text-slate-400">{r.hint}</span>
              )}
            </span>
          </div>
        ))}
      </div>
      {footer && (
        <div className="mt-2 border-t border-slate-200 pt-2 text-[11px] text-slate-500 dark:border-slate-700 dark:text-slate-400">
          {footer}
        </div>
      )}
    </div>
  );
}
