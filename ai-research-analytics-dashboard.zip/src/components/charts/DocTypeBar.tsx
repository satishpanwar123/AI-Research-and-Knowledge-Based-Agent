import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import ChartTooltip from "./ChartTooltip";
import { chartTheme } from "../../hooks/useTheme";
import { compact, type Bucket } from "../../lib/data";

export default function DocTypeBar({ data, dark }: { data: Bucket[]; dark: boolean }) {
  const th = chartTheme(dark);
  const total = data.reduce((a, b) => a + b.value, 0) || 1;

  return (
    <div>
    <ResponsiveContainer width="100%" height={244}>
      <BarChart data={data} margin={{ top: 8, right: 6, left: -18, bottom: 0 }} barGap={4}>
        <defs>
          <linearGradient id="barDocs" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#6366f1" stopOpacity={0.95} />
            <stop offset="100%" stopColor="#818cf8" stopOpacity={0.55} />
          </linearGradient>
          <linearGradient id="barQs" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#06b6d4" stopOpacity={0.95} />
            <stop offset="100%" stopColor="#22d3ee" stopOpacity={0.5} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={th.grid} strokeDasharray="4 6" vertical={false} />
        <XAxis
          dataKey="label"
          tickFormatter={(v: string) => (v.length > 12 ? `${v.slice(0, 11)}…` : v)}
          tick={{ fill: th.axis, fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          interval={0}
          dy={6}
        />
        <YAxis
          tickFormatter={(v: number) => compact(v)}
          tick={{ fill: th.axis, fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          width={54}
        />
        <Tooltip
          cursor={{ fill: th.cursor }}
          content={({ active, payload, label }: any) => {
            if (!active || !payload?.length) return null;
            const row = payload[0].payload as Bucket;
            return (
              <ChartTooltip
                dark={dark}
                title={label}
                rows={[
                  { label: "Documents", value: compact(row.value), color: "#6366f1" },
                  { label: "Questions", value: compact(row.secondary), color: "#06b6d4" },
                ]}
                footer={
                  <>
                    <div className="flex justify-between gap-6">
                      <span>Share of volume</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-200">
                        {((row.value / total) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between gap-6">
                      <span>Questions / doc</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-200">
                        {(row.secondary / Math.max(1, row.value)).toFixed(1)}
                      </span>
                    </div>
                  </>
                }
              />
            );
          }}
        />
        <Bar dataKey="value" name="Documents" fill="url(#barDocs)" radius={[6, 6, 0, 0]} maxBarSize={26} animationDuration={700} />
        <Bar dataKey="secondary" name="Questions" fill="url(#barQs)" radius={[6, 6, 0, 0]} maxBarSize={26} animationDuration={850} />
      </BarChart>
    </ResponsiveContainer>
      <div className="mt-2 flex items-center justify-center gap-5 text-[11px] text-slate-500 dark:text-slate-400">
        <span className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-sm" style={{ background: "#6366f1" }} />
          Documents
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-sm" style={{ background: "#06b6d4" }} />
          Questions
        </span>
      </div>
    </div>
  );
}
