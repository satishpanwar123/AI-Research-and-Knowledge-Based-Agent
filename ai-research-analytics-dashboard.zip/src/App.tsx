import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Clock,
  FileText,
  Gauge,
  MessagesSquare,
  Users,
} from "lucide-react";
import Sidebar from "./components/Sidebar";
import Topbar from "./components/Topbar";
import FilterBar, { type RangeKey } from "./components/FilterBar";
import KpiCard from "./components/KpiCard";
import Card from "./components/Card";
import DocumentTable from "./components/DocumentTable";
import DocumentDrawer from "./components/DocumentDrawer";
import ActivityTrend, { METRICS, type MetricKey } from "./components/charts/ActivityTrend";
import DocTypeBar from "./components/charts/DocTypeBar";
import AudienceDonut from "./components/charts/AudienceDonut";
import WeekdayStack, { type WeekSeries } from "./components/charts/WeekdayStack";
import TopicBars from "./components/charts/TopicBars";
import { useTheme, SERIES } from "./hooks/useTheme";
import {
  AUDIENCES,
  DAY_DATA,
  DAYS,
  DOCUMENTS,
  DOC_TYPES,
  DAY_INDEX,
  SOURCES,
  buildCombos,
  bucketBy,
  compact,
  delta,
  longDate,
  nf,
  nf1,
  resample,
  seriesFor,
  sparkline,
  summarize,
  topicBreakdown,
  type Doc,
} from "./lib/data";

const PRESET_DAYS: Record<string, number> = { "7d": 7, "30d": 30, "90d": 90, "365d": 365 };
const GRAN = ["day", "week", "month"] as const;

export default function App() {
  const { dark, toggle } = useTheme();

  const [page, setPage] = useState("Overview");
  const [navOpen, setNavOpen] = useState(false);
  const [range, setRange] = useState<RangeKey>("90d");
  const [start, setStart] = useState(DAY_DATA[DAYS - 90].iso);
  const [end, setEnd] = useState(DAY_DATA[DAYS - 1].iso);
  const [audiences, setAudiences] = useState<string[]>([...AUDIENCES]);
  const [docTypes, setDocTypes] = useState<string[]>([...DOC_TYPES]);
  const [sources, setSources] = useState<string[]>([...SOURCES]);
  const [metric, setMetric] = useState<MetricKey>("docs");
  const [gran, setGran] = useState<(typeof GRAN)[number]>(
    "week"
  );
  const [search, setSearch] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [lastSync, setLastSync] = useState("2 min ago");
  const [selected, setSelected] = useState<Doc | null>(null);
  const [asked, setAsked] = useState(0);

  /* ------------------------- date window ------------------------- */
  useEffect(() => {
    if (range === "custom") return;
    const n = PRESET_DAYS[range];
    setStart(DAY_DATA[Math.max(0, DAYS - n)].iso);
    setEnd(DAY_DATA[DAYS - 1].iso);
  }, [range]);

  const { from, to } = useMemo(() => {
    if (range === "custom") {
      const f = DAY_INDEX[start] ?? 0;
      const t = DAY_INDEX[end] ?? DAYS - 1;
      return { from: Math.min(f, t), to: Math.max(f, t) };
    }
    const n = PRESET_DAYS[range];
    return { from: Math.max(0, DAYS - n), to: DAYS - 1 };
  }, [range, start, end]);

  const span = to - from + 1;
  const prevFrom = Math.max(0, from - span);
  const prevTo = Math.max(0, from - 1);

  /* --------------------------- analytics -------------------------- */
  const combos = useMemo(
    () => buildCombos(docTypes, audiences, sources),
    [docTypes, audiences, sources]
  );
  const comboKey = combos.join(",");

  const series = useMemo(() => seriesFor(from, to, combos), [from, to, comboKey]); // eslint-disable-line
  const prevSeries = useMemo(
    () => (prevTo > prevFrom ? seriesFor(prevFrom, prevTo, combos) : []),
    [prevFrom, prevTo, comboKey] // eslint-disable-line
  );

  const totals = useMemo(() => summarize(series), [series]);
  const prevTotals = useMemo(
    () => (prevSeries.length ? summarize(prevSeries) : null),
    [prevSeries]
  );

  const weekly = useMemo(() => resample(series, gran), [series, gran]);
  const weeklyPrev = useMemo(() => resample(prevSeries, gran), [prevSeries, gran]);

  const byDocType = useMemo(
    () => bucketBy(from, to, combos, "dt").map((b, i) => ({ ...b, color: SERIES[i] })),
    [from, to, comboKey] // eslint-disable-line
  );
  const byAudience = useMemo(
    () =>
      bucketBy(from, to, combos, "au").map((b, i) => ({
        ...b,
        color: SERIES[i % SERIES.length],
        value: b.secondary,
        secondary: b.value,
      })),
    [from, to, comboKey] // eslint-disable-line
  );
  const bySource = useMemo(
    () => bucketBy(from, to, combos, "so").map((b, i) => ({ ...b, color: SERIES[i % SERIES.length] })),
    [from, to, comboKey] // eslint-disable-line
  );

  const weekSeries = useMemo<WeekSeries[]>(() => {
    if (!combos.length) return [];
    const order = [1, 2, 3, 4, 5, 6, 0]; // Mon..Sun
    return audiences.map((a) => {
      const pts = seriesFor(from, to, buildCombos(docTypes, [a], sources));
      const sums = new Array(7).fill(0);
      const counts = new Array(7).fill(0);
      pts.forEach((p) => {
        sums[p.dow] += p.queries;
        counts[p.dow] += 1;
      });
      return {
        name: a,
        values: order.map((d) => (counts[d] ? sums[d] / counts[d] : 0)),
      };
    });
  }, [from, to, comboKey, audiences, docTypes, sources]); // eslint-disable-line

  const topics = useMemo(
    () => topicBreakdown(totals.docs, docTypes, audiences),
    [totals.docs, docTypes, audiences]
  );

  const tableDocs = useMemo(() => {
    const t0 = DAY_DATA[from].ts;
    const t1 = DAY_DATA[to].ts;
    const aSet = new Set(audiences);
    const dSet = new Set(docTypes);
    const sSet = new Set(sources);
    return DOCUMENTS.filter(
      (d) =>
        d.ts >= t0 &&
        d.ts <= t1 &&
        aSet.has(d.audience) &&
        dSet.has(d.type) &&
        sSet.has(d.source)
    );
  }, [from, to, audiences, docTypes, sources]);

  /* --------------------------- handlers --------------------------- */
  const resetAll = useCallback(() => {
    setRange("90d");
    setAudiences([...AUDIENCES]);
    setDocTypes([...DOC_TYPES]);
    setSources([...SOURCES]);
  }, []);

  const refresh = useCallback(() => {
    setRefreshing(true);
    setLastSync("syncing…");
    window.setTimeout(() => {
      setRefreshing(false);
      setLastSync("just now");
    }, 850);
  }, []);

  const d = (curr: number, prev: number) => delta(curr, prev);
  const pv = (k: keyof NonNullable<typeof prevTotals>) => (prevTotals ? (prevTotals[k] as number) : 0);

  const dirty =
    range !== "90d" ||
    audiences.length !== AUDIENCES.length ||
    docTypes.length !== DOC_TYPES.length ||
    sources.length !== SOURCES.length;

  const activeFilters = `${audiences.length}/${AUDIENCES.length} audiences · ${docTypes.length}/${DOC_TYPES.length} types · ${sources.length}/${SOURCES.length} sources`;

  const sourceTotal = bySource.reduce((a, b) => a + b.value, 0) || 1;
  const noSegments = combos.length === 0;

  return (
    <div className="theme-t flex min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <Sidebar
        active={page}
        onSelect={setPage}
        open={navOpen}
        onClose={() => setNavOpen(false)}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar
          dark={dark}
          onToggleTheme={toggle}
          onMenu={() => setNavOpen(true)}
          query={search}
          onQuery={setSearch}
          lastSync={lastSync}
          onRefresh={refresh}
          refreshing={refreshing}
          page={page}
        />

        <main className="flex-1 px-4 pb-10 pt-1 sm:px-6">
          <FilterBar
            range={range}
            onRange={setRange}
            start={start}
            end={end}
            onStart={setStart}
            onEnd={setEnd}
            audiences={audiences}
            onAudiences={setAudiences}
            docTypes={docTypes}
            onDocTypes={setDocTypes}
            sources={sources}
            onSources={setSources}
            onReset={resetAll}
            periodLabel={`${longDate(DAY_DATA[from].iso)} – ${longDate(DAY_DATA[to].iso)} · ${span} days`}
            compareLabel={`${longDate(DAY_DATA[prevFrom].iso)} – ${longDate(DAY_DATA[Math.max(prevFrom, prevTo)].iso)}`}
            dirty={dirty}
          />

          {noSegments && (
            <div className="mb-5 flex items-center justify-between gap-3 rounded-xl border border-amber-300/60 bg-amber-50 px-4 py-3 dark:border-amber-500/30 dark:bg-amber-500/10">
              <p className="text-[13px] font-medium text-amber-800 dark:text-amber-300">
                No segments selected — every metric is currently zero.
              </p>
              <button
                onClick={resetAll}
                className="rounded-lg bg-amber-600 px-3 py-1.5 text-[12px] font-semibold text-white hover:bg-amber-700"
              >
                Reset filters
              </button>
            </div>
          )}

          {/* ------------------------- KPI row ------------------------- */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
            <KpiCard
              label="Documents processed"
              value={compact(totals.docs)}
              delta={d(totals.docs, pv("docs"))}
              spark={sparkline(series, "docs")}
              color="#6366f1"
              icon={FileText}
              hint={`${compact(totals.docs / Math.max(1, span))} per day on average`}
              delay={0}
              active={metric === "docs"}
              onClick={() => setMetric("docs")}
            />
            <KpiCard
              label="Questions answered"
              value={compact(totals.queries)}
              delta={d(totals.queries, pv("queries"))}
              spark={sparkline(series, "queries")}
              color="#06b6d4"
              icon={MessagesSquare}
              hint={`${totals.queriesPerDoc.toFixed(1)} questions per document`}
              delay={60}
              active={metric === "queries"}
              onClick={() => setMetric("queries")}
            />
            <KpiCard
              label="Time saved"
              value={compact(totals.hoursSaved)}
              unit="hrs"
              delta={d(totals.hoursSaved, pv("hoursSaved"))}
              spark={sparkline(series, "timeSaved")}
              color="#f59e0b"
              icon={Clock}
              hint={`${nf1.format(totals.minutesPerDoc)} min saved per document`}
              delay={120}
              active={metric === "timeSaved"}
              onClick={() => setMetric("timeSaved")}
            />
            <KpiCard
              label="Active users"
              value={compact(totals.activeUsers)}
              unit="/ day"
              delta={d(totals.activeUsers, pv("activeUsers"))}
              spark={sparkline(series, "users")}
              color="#ec4899"
              icon={Users}
              hint={`${compact(totals.queries / Math.max(1, totals.activeUsers * span))} questions per user`}
              delay={180}
              active={metric === "users"}
              onClick={() => setMetric("users")}
            />
            <KpiCard
              label="Answer confidence"
              value={(totals.quality * 100).toFixed(1)}
              unit="%"
              delta={totals.quality - pv("quality")}
              deltaLabel="Change in percentage points vs previous period"
              spark={sparkline(series, "quality")}
              color="#10b981"
              icon={Gauge}
              hint={`${compact(totals.citations)} citations verified`}
              delay={240}
            />
          </div>

          {/* --------------------- trend + donut ---------------------- */}
          <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
            <Card
              className="lg:col-span-2"
              delay={280}
              title="Processing activity"
              subtitle={`${METRICS.find((m) => m.key === metric)!.label} · ${
                gran === "day" ? "daily" : gran === "week" ? "weekly" : "monthly"
              } view`}
              actions={
                <div className="flex flex-wrap items-center gap-1.5">
                  <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 p-0.5 dark:border-slate-700 dark:bg-slate-800/60">
                    {METRICS.slice(0, 3).map((m) => (
                      <button
                        key={m.key}
                        onClick={() => setMetric(m.key)}
                        className={`rounded-md px-2 py-1 text-[11px] font-semibold transition-colors ${
                          metric === m.key
                            ? "bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white"
                            : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                        }`}
                      >
                        {m.label.split(" ")[0]}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 p-0.5 dark:border-slate-700 dark:bg-slate-800/60">
                    {GRAN.map((g) => (
                      <button
                        key={g}
                        onClick={() => setGran(g)}
                        className={`rounded-md px-2 py-1 text-[11px] font-semibold uppercase transition-colors ${
                          gran === g
                            ? "bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white"
                            : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
                        }`}
                      >
                        {g[0]}
                      </button>
                    ))}
                  </div>
                </div>
              }
            >
              <ActivityTrend
                points={weekly}
                prev={weeklyPrev}
                metric={metric}
                dark={dark}
                gran={gran}
              />
              <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-slate-100 pt-3 text-[11px] text-slate-500 dark:border-slate-800 dark:text-slate-400">
                <span className="flex items-center gap-1.5">
                  <span className="h-0.5 w-4 rounded-full" style={{ background: METRICS.find((m) => m.key === metric)!.color }} />
                  Current period
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-0.5 w-4 rounded-full" style={{ background: dark ? "#64748b" : "#94a3b8" }} />
                  Previous {span} days
                </span>
                <span className="ml-auto">
                  Peak {compact(Math.max(0, ...series.map((p) => p[metric] as number)))} · Avg{" "}
                  {compact(
                    series.reduce((a, p) => a + (p[metric] as number), 0) / Math.max(1, series.length)
                  )}
                </span>
              </div>
            </Card>

            <Card
              delay={340}
              title="Audience mix"
              subtitle="Questions asked by segment"
            >
              <AudienceDonut data={byAudience} dark={dark} title="questions" />
            </Card>
          </div>

          {/* ---------------------- source strip ---------------------- */}
          <Card
            className="mt-4"
            delay={400}
            title="Source contribution"
            subtitle={`Where ingested documents come from · ${activeFilters}`}
            bodyClass="space-y-2.5"
          >
            <div className="flex h-3 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
              {bySource.map((s) => (
                <div
                  key={s.key}
                  title={`${s.key}: ${nf.format(s.value)} docs (${((s.value / sourceTotal) * 100).toFixed(1)}%)`}
                  className="h-full transition-all duration-700 ease-out hover:brightness-110"
                  style={{
                    width: `${(s.value / sourceTotal) * 100}%`,
                    background: s.color,
                  }}
                />
              ))}
            </div>
            <div className="flex flex-wrap gap-x-4 gap-y-1.5">
              {bySource.map((s) => (
                <span
                  key={s.key}
                  className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400"
                >
                  <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                  {s.key}
                  <span className="font-semibold text-slate-700 dark:text-slate-200">
                    {((s.value / sourceTotal) * 100).toFixed(1)}%
                  </span>
                  <span className="text-slate-400">({compact(s.value)})</span>
                </span>
              ))}
            </div>
          </Card>

          {/* ---------------------- second row ------------------------ */}
          <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
            <Card
              delay={460}
              title="Volume by document type"
              subtitle="Documents ingested vs. questions asked"
            >
              <DocTypeBar data={byDocType} dark={dark} />
            </Card>

            <Card
              delay={520}
              title="Weekly rhythm"
              subtitle="Average questions per day, stacked by audience"
            >
              <WeekdayStack series={weekSeries} dark={dark} />
            </Card>

            <Card
              delay={580}
              title="Top research topics"
              subtitle={`Estimated from ${compact(totals.docs)} processed documents`}
            >
              <TopicBars data={topics} dark={dark} />
              <p className="mt-4 rounded-lg bg-slate-50 p-3 text-[11px] leading-relaxed text-slate-500 dark:bg-slate-800/50 dark:text-slate-400">
                <span className="font-semibold text-slate-700 dark:text-slate-200">Insight:</span>{" "}
                {topics[0]?.label} leads with{" "}
                {((topics[0]?.secondary ?? 0) * 100).toFixed(0)}% of volume across{" "}
                {audiences.length} audience segment{audiences.length === 1 ? "" : "s"}. Deep-research
                runs on this topic average{" "}
                {nf1.format(totals.minutesPerDoc * 1.4)} minutes saved per document.
              </p>
            </Card>
          </div>

          {/* ------------------------- table -------------------------- */}
          <div className="mt-4">
            <DocumentTable
              docs={tableDocs}
              search={search}
              onSearch={setSearch}
              onOpen={setSelected}
            />
          </div>

          <footer className="mt-6 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
            <span>
              Cortex Research Intelligence · synthetic demo data · {DAY_DATA[from].iso} →{" "}
              {DAY_DATA[to].iso}
            </span>
            <span>
              {nf.format(DOCUMENTS.length)} documents in the workspace index
              {asked > 0 ? ` · ${asked} question${asked === 1 ? "" : "s"} asked this session` : ""}
            </span>
          </footer>
        </main>
      </div>

      <DocumentDrawer
        doc={selected}
        onClose={() => setSelected(null)}
        onOpenOther={setSelected}
        onAsk={() => setAsked((a) => a + 1)}
      />
    </div>
  );
}
