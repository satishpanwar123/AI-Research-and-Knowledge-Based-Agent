import type { Doc } from "./data";

function mulberry32(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function seedOf(id: string) {
  let h = 0x811c9dc5;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}
const pick = <T,>(rnd: () => number, arr: readonly T[]) => arr[Math.floor(rnd() * arr.length)];
const ri = (rnd: () => number, a: number, b: number) => Math.floor(a + rnd() * (b - a + 1));

const METHODS = [
  "retrieval-augmented generation",
  "instruction tuning with sparse mixture-of-experts routing",
  "hierarchical chunking with multi-vector indexing",
  "contrastive pre-training over citation graphs",
  "chain-of-thought distillation into a 7B student model",
  "graph-based retrieval over entity-linked passages",
  "self-consistency sampling with verifier reranking",
  "long-context attention with learned chunk selection",
];
const BASELINES = [
  "a strong BM25 retrieve-then-read pipeline",
  "the previous state-of-the-art dense retriever",
  "naive full-context prompting",
  "human expert annotators",
  "a fine-tuned 13B assistant without retrieval",
];
const CORPORA = [
  "a corpus of 1.2M open-access preprints",
  "the arXiv cs.* dump (2018–2025)",
  "PubMed Central abstracts with full-text links",
  "our internal knowledge base of 48k indexed documents",
  "a 240k-page collection of technical manuals and slide decks",
];
const BENCHMARKS = [
  "MMLU, GPQA and a domain-specific exam set",
  "a 500-query expert-rated evaluation set",
  "long-document QA benchmarks (NarrativeQA, QASPER)",
  "held-out citation-grounded questions from our user logs",
];
const METRICS = [
  ["answer faithfulness", "+18.4%"],
  ["retrieval recall@20", "+12.1%"],
  ["citation accuracy", "+9.6%"],
  ["time-to-insight", "−41%"],
  ["hallucination rate", "−33%"],
] as const;
const VENUES = ["NeurIPS", "ICML", "ICLR", "ACL", "EMNLP", "CVPR", "ACM CHI", "JMLR", "Nature Methods", "arXiv preprint"];
const SECTION_POOL = [
  "Introduction",
  "Related Work",
  "Method",
  "Theoretical Analysis",
  "Experimental Setup",
  "Results",
  "Ablation Study",
  "Limitations",
  "Broader Impact",
  "Conclusion",
];
const FIRST = ["A.", "M.", "L.", "S.", "R.", "J.", "K.", "P.", "T.", "N.", "D.", "C.", "E.", "H."];
const LAST = [
  "Ramanathan", "Okonkwo", "Lindqvist", "Bhattacharya", "Ferreira", "Nakamura", "Adeyemi",
  "Kowalski", "Vasquez", "Haddad", "Petrov", "Nowak", "Aliyev", "Bergström", "Castellanos",
  "Duarte", "Ibrahim", "Jensen", "Kaur", "Moreau",
];
const ENTITIES = [
  "transformer", "embedding index", "chunking strategy", "citation graph", "evaluation harness",
  "prompt template", "verifier model", "vector store", "annotation protocol", "ablation suite",
  "token budget", "context window", "reranker", "knowledge graph", "benchmark suite",
];

export type DocDetail = {
  abstract: string;
  shortSummary: string;
  keyFindings: string[];
  sections: { title: string; pages: number }[];
  citations: { authors: string; year: number; title: string; venue: string }[];
  faq: { q: string; a: string }[];
  engagement: number[];
  entities: string[];
  readingMinutes: number;
  authors: string[];
  venue: string;
  year: number;
};

export function detailFor(doc: Doc): DocDetail {
  const rnd = mulberry32(seedOf(doc.id + doc.topic));
  const method = pick(rnd, METHODS);
  const baseline = pick(rnd, BASELINES);
  const corpus = pick(rnd, CORPORA);
  const bench = pick(rnd, BENCHMARKS);
  const [metric, metricGain] = pick(rnd, METRICS);
  const venue = pick(rnd, VENUES);
  const year = ri(rnd, 2021, 2025);
  const nFindings = ri(rnd, 3, 4);
  const conf = (doc.confidence * 100).toFixed(1);

  const abstract =
    `We study how ${doc.audience.toLowerCase()} turn long, heterogeneous documents into reliable answers. ` +
    `This ${doc.type.toLowerCase()} introduces an approach built on ${method}, evaluated against ${baseline} ` +
    `over ${corpus}. Across ${bench} the method improves ${metric} by ${metricGain}, while keeping the evidence ` +
    `trail auditable: every claim is anchored to a passage with a verifiable citation. We further report reading-time ` +
    `measurements from ${Math.max(12, Math.round(doc.questions / 6))} participants, showing that structured summaries ` +
    `reduce time-to-insight without degrading comprehension.`;

  const shortSummary =
    `${doc.type} on ${doc.topic.toLowerCase()} (${doc.pages} pages). Uses ${method} and reports ` +
    `${metricGain} ${metric} over ${baseline}. Answer confidence on this document is ${conf}% across ` +
    `${doc.questions} questions asked.`;

  const findings = [
    `${method.charAt(0).toUpperCase() + method.slice(1)} improves ${metric} by ${metricGain} relative to ${baseline} (p < 0.01, n = ${ri(rnd, 320, 1800)} trials).`,
    `Grounding every sentence in a retrieved passage cuts unsupported claims from ${ri(rnd, 9, 17)}% to ${ri(rnd, 1, 4)}%, verified by ${ri(rnd, 3, 6)} independent raters.`,
    `Median time-to-insight drops from ${ri(rnd, 34, 52)} minutes to ${ri(rnd, 8, 19)} minutes for ${doc.audience.toLowerCase()} working through the full document.`,
    `Gains hold across ${bench}, but degrade when passages exceed ${ri(rnd, 4, 12)}k tokens — chunk boundary selection matters more than retriever size.`,
    `Qualitatively, users preferred cited answers ${ri(rnd, 68, 92)}% of the time, even when uncited answers were rated equally correct.`,
  ].slice(0, nFindings);

  const nSections = Math.min(SECTION_POOL.length, Math.max(5, Math.round(doc.pages / 4)));
  const sections = Array.from({ length: nSections }, (_, i) => ({
    title: `${i + 1}. ${SECTION_POOL[i % SECTION_POOL.length]}`,
    pages: Math.max(1, Math.round(doc.pages / nSections)),
  }));

  const nCites = ri(rnd, 4, 6);
  const citations = Array.from({ length: nCites }, () => {
    const n = ri(rnd, 2, 3);
    const authors = Array.from({ length: n }, () => `${pick(rnd, FIRST)} ${pick(rnd, LAST)}`);
    return {
      authors: n === 3 ? `${authors[0]}, ${authors[1]} & ${authors[2]}` : authors.join(" & "),
      year: ri(rnd, 2018, year - 1),
      title: `${pick(rnd, ["Efficient", "Robust", "Scalable", "Grounded", "Compositional", "Self-Supervised"])} ${pick(rnd, ["retrieval", "summarisation", "verification", "alignment", "indexing", "distillation"])} for ${pick(rnd, ["long documents", "technical corpora", "multi-modal sources", "scholarly text", "enterprise knowledge bases"])}`,
      venue: pick(rnd, VENUES),
    };
  }).sort((a, b) => b.year - a.year);

  const authors = Array.from({ length: ri(rnd, 2, 4) }, () => `${pick(rnd, FIRST)} ${pick(rnd, LAST)}`);

  const faq = [
    {
      q: "What is the single main contribution?",
      a: `The core contribution is ${method}, which improves ${metric} by ${metricGain} over ${baseline}. Everything else in the document — the evaluation harness, the citation protocol and the ablations — exists to make that result reproducible.`,
    },
    {
      q: "Which data and benchmarks were used?",
      a: `Experiments run over ${corpus} and report results on ${bench}. Documents average ${Math.round(doc.tokens / doc.pages)} tokens per page, and this copy is ${doc.pages} pages (${doc.tokens.toLocaleString()} tokens) long.`,
    },
    {
      q: "How trustworthy are the extracted answers?",
      a: `Answer confidence for this document is ${conf}%, computed across ${doc.questions} questions and ${doc.citations} verified citations. Unsupported-claim rate is the metric to watch: ${findings[1].split("cuts ")[1]?.split(",")[0] ?? "under 5%"} in the reported runs.`,
    },
    {
      q: "What are the limitations?",
      a: `The authors flag three: (1) evaluation is English-only, (2) chunk boundaries still matter for very long passages, and (3) expert raters, not end users, produced most of the ground truth. Cited evidence is stored with the document, so you can audit any claim.`,
    },
  ];

  // 30-day engagement trace, deterministic per document
  const engagement = Array.from({ length: 30 }, (_, i) => {
    const decay = Math.pow(0.94, 29 - i);
    const weekly = i % 7 === 5 || i % 7 === 6 ? 0.45 : 1;
    const base = (doc.questions / 12) * decay * weekly;
    return Math.max(0, base * (0.6 + rnd() * 0.9));
  });

  const entities = Array.from(new Set(Array.from({ length: 6 }, () => pick(rnd, ENTITIES))));

  return {
    abstract,
    shortSummary,
    keyFindings: findings,
    sections,
    citations,
    faq,
    engagement,
    entities,
    readingMinutes: Math.max(4, Math.round(doc.pages * 1.6)),
    authors,
    venue,
    year,
  };
}

export function freeformAnswer(doc: Doc, question: string) {
  const rnd = mulberry32(seedOf(doc.id + question));
  return (
    `Based on this ${doc.type.toLowerCase()} (${doc.pages} pages, retrieved from ${doc.source}), the relevant evidence is in the ` +
    `${pick(rnd, ["Method", "Results", "Discussion", "Experimental Setup"])} section. ` +
    `${pick(rnd, [
      "The authors report",
      "The reported evidence suggests",
      "Across the evaluated settings, the paper finds",
    ])} ${pick(rnd, [
      "a consistent improvement over the stated baseline",
      "that the effect is strongest on long, citation-dense passages",
      "that gains are modest but statistically significant",
    ])}. ` +
    `Answer confidence is ${(doc.confidence * 100).toFixed(1)}% across ${doc.questions} questions asked on this document, ` +
    `with ${doc.citations} verified citations available for audit. ` +
    `Caveat: ${pick(rnd, [
      "the evaluation is English-only",
      "chunk boundary selection still drives most of the variance",
      "ground truth was produced by expert raters rather than end users",
    ])}.`
  );
}
