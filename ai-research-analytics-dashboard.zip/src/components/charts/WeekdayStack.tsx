import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import ChartTooltip from "./ChartTooltip";
import { chartTheme, SERIES } from "../../hooks/useTheme";
import { compact } from "../../lib/data";

export type WeekSeries = { name: string; values: number[] };

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export default function WeekdayStack({
  series,
  dark,
}: {
  series: WeekSeries[];
  dark: boolean;
}) {
  const th = chartTheme(dark);
  const data = DAYS.map((d, i) => {
    const row: Record<string, number | string> = { day: d };
    series.forEach((s) => {
      row[s.name] = Math.round(s.values[i] || 0);
    });
    return row;
  });
  const totals = data.map((d) =>
    series.reduce((a, s) => a + ((d[s.name] as number) || 0), 0)
  );

  return (
    <div>
    <ResponsiveContainer width="100%" height={244}>
      <BarChart data={data} margin={{ top: 8, right: 6, left: -18, bottom: 0 }}>
        <CartesianGrid stroke={th.grid} strokeDasharray="4 6" vertical={false} />
        <XAxis
          dataKey="day"
          tick={{ fill: th.axis, fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          dy={6}
        />
        <YAxis
          tickFormatter={(v: number) => compact(v)}
          tick={{ fill: th.axis, fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          width={54}
        />
        <Tooltip
          cursor={{ fill: th.cursor }}
          content={({ active, payload, label }: any) => {
            if (!active || !payload?.length) return null;
            const rows = [...payload].reverse().map((p: any) => ({
              label: p.name,
              value: compact(p.value as number),
              color: p.color,
            }));
            const total = payload.reduce((a: number, p: any) => a + (p.value as number), 0);
            return (
              <ChartTooltip
                dark={dark}
                title={`${compact(total)} questions`}
                subtitle={`Avg. ${label}`}
                rows={rows}
                footer={`Busiest day rank: #${totals.indexOf(total) + 1} of 7`}
              />
            );
          }}
        />
        {series.map((s, i) => (
          <Bar
            key={s.name}
            dataKey={s.name}
            stackId="a"
            fill={SERIES[i % SERIES.length]}
            radius={i === series.length - 1 ? [6, 6, 0, 0] : [0, 0, 0, 0]}
            maxBarSize={38}
            animationDuration={600 + i * 120}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
      <div className="mt-2 flex flex-wrap items-center justify-center gap-x-3.5 gap-y-1 text-[11px] text-slate-500 dark:text-slate-400">
        {series.map((s, i) => (
          <span key={s.name} className="flex items-center gap-1.5">
            <span
              className="h-2 w-2 rounded-sm"
              style={{ background: SERIES[i % SERIES.length] }}
            />
            {s.name}
          </span>
        ))}
      </div>
    </div>
  );
}
